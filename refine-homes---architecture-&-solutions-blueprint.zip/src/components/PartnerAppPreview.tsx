import React, { useState, useEffect } from 'react';
import {
  calculatePlatformSplit,
} from '../utils/pricing';
import { Currency, RupeeIcon } from './Currency';
import {
  Radio,
  CheckCircle2,
  XCircle,
  FileText,
  ShieldCheck,
  Wallet,
  Clock,
  MapPin,
  Camera,
  ChevronRight,
  TrendingUp,
  UserCheck,
  Building,
  Upload,
  AlertTriangle,
} from 'lucide-react';

interface PartnerAppPreviewProps {
  onAcceptJob?: (job: any) => void;
  incomingJobAlert?: any;
}

export const PartnerAppPreview: React.FC<PartnerAppPreviewProps> = ({
  onAcceptJob,
  incomingJobAlert,
}) => {
  const [activePartnerTab, setActivePartnerTab] = useState<
    'radar' | 'quote' | 'milestones' | 'wallet' | 'kyc'
  >('radar');

  const [isOnline, setIsOnline] = useState(true);
  const [countdown, setCountdown] = useState(28);
  const [hasJob, setHasJob] = useState(false);
  const [jobAcceptedNotice, setJobAcceptedNotice] = useState(false);

  // Digital Quote Generator state (Painting / Inspection)
  const [rooms, setRooms] = useState([
    { name: 'Living Room', length: 18, width: 14, height: 10, windowsDeduction: 40 },
    { name: 'Master Bed', length: 15, width: 12, height: 10, windowsDeduction: 30 },
  ]);
  const [selectedBrandTier, setSelectedBrandTier] = useState<'economy' | 'premium' | 'luxury'>('premium');

  // Milestone checklist state
  const [milestone1Uploaded, setMilestone1Uploaded] = useState(true);
  const [milestone2Uploaded, setMilestone2Uploaded] = useState(false);
  const [milestone3Uploaded, setMilestone3Uploaded] = useState(false);

  // Partner wallet state
  const [walletBalance, setWalletBalance] = useState(14850);
  const [escrowPending, setEscrowPending] = useState(9600);
  const [lifetimeEarnings, setLifetimeEarnings] = useState(182400);
  const [payoutRequested, setPayoutRequested] = useState(false);

  // 30s Countdown timer effect
  useEffect(() => {
    if (!hasJob && countdown > 0) {
      const timer = setInterval(() => {
        setCountdown((c) => (c > 1 ? c - 1 : 30));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [hasJob, countdown]);

  const handleAccept = () => {
    setHasJob(true);
    setJobAcceptedNotice(true);
    if (onAcceptJob) {
      onAcceptJob({ id: 'RFN-9812', customer: 'Ananya Sharma', address: 'Indiranagar 100ft Rd', amount: 3299 });
    }
    setTimeout(() => setJobAcceptedNotice(false), 3000);
  };

  const handleReject = () => {
    setCountdown(30);
  };

  // Measurement calc
  const totalWallSqFt = rooms.reduce((acc, r) => {
    const perimeter = 2 * (r.length + r.width);
    const wallArea = perimeter * r.height - r.windowsDeduction;
    return acc + wallArea;
  }, 0);

  const quoteRate = selectedBrandTier === 'economy' ? 14 : selectedBrandTier === 'premium' ? 24 : 38;
  const quoteTotal = Math.round(totalWallSqFt * quoteRate * 1.18); // with GST

  return (
    <div className="flex flex-col items-center">
      {/* Mobile Device Frame */}
      <div className="w-[380px] h-[780px] bg-slate-950 rounded-[44px] border-4 border-slate-700 shadow-2xl overflow-hidden flex flex-col relative">
        {/* Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-5 bg-slate-900 rounded-full flex items-center justify-center z-30">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-800 mr-2" />
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500/80" />
        </div>

        {/* Partner Header */}
        <div className="bg-slate-900 px-4 pt-8 pb-3 border-b border-slate-800 text-white shrink-0 z-20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-xs text-slate-950">
                RP
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-xs text-white">Ramesh Patel</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    KYC Verified
                  </span>
                </div>
                <div className="text-[10px] text-slate-400">Master Painter & Wall Specialist</div>
              </div>
            </div>

            {/* Online Toggle */}
            <button
              onClick={() => setIsOnline(!isOnline)}
              className={`px-2 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                isOnline
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  isOnline ? 'bg-emerald-400 animate-ping' : 'bg-rose-400'
                }`}
              />
              <span>{isOnline ? 'ON DUTY' : 'OFFLINE'}</span>
            </button>
          </div>

          {/* Partner Tab Switcher */}
          <div className="grid grid-cols-5 gap-1 mt-3">
            {[
              { id: 'radar', label: 'Radar', icon: <Radio className="w-3 h-3" /> },
              { id: 'quote', label: 'Estimator', icon: <FileText className="w-3 h-3" /> },
              { id: 'milestones', label: 'Stages', icon: <ShieldCheck className="w-3 h-3" /> },
              { id: 'wallet', label: 'Earnings', icon: <Wallet className="w-3 h-3" /> },
              { id: 'kyc', label: 'KYC', icon: <UserCheck className="w-3 h-3" /> },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActivePartnerTab(tab.id as any)}
                className={`p-1.5 rounded-lg flex flex-col items-center text-[10px] transition-all cursor-pointer ${
                  activePartnerTab === tab.id
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                }`}
              >
                {tab.icon}
                <span className="mt-0.5">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Partner Body Content */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 bg-slate-950 text-white text-xs">
          {/* TAB 1: RADAR & 30-SEC DISPATCH AUCTION */}
          {activePartnerTab === 'radar' && (
            <div className="space-y-3">
              {!hasJob ? (
                <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950/60 p-4 rounded-2xl border border-indigo-500/40 text-center relative overflow-hidden">
                  {/* Countdown Badge */}
                  <div className="inline-flex items-center gap-1.5 bg-rose-500/20 text-rose-400 border border-rose-500/40 px-3 py-1 rounded-full text-xs font-bold mb-2">
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    <span>Auto-Timeout: {countdown}s</span>
                  </div>

                  <h3 className="font-bold text-white text-sm">New Dispatch Alert Nearby!</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    1.4 km away • Indiranagar Stage 2, BLR
                  </p>

                  {/* Job Specs */}
                  <div className="mt-3 bg-slate-950 p-3 rounded-xl border border-slate-800 text-left space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">Service:</span>
                      <strong className="text-white">Premium Wall Painting (3BHK)</strong>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">Estimated Gross Value:</span>
                      <Currency amount={38500} className="text-amber-400 font-mono text-sm font-bold" />
                    </div>
                    <div className="flex justify-between items-center text-[10px] pt-1.5 border-t border-slate-800">
                      <span className="text-slate-400">Your Net Earnings (80%):</span>
                      <Currency amount={30800} className="text-emerald-400 font-mono font-bold" />
                    </div>
                    <div className="text-[9px] text-slate-500">
                      Refine Homes platform take-rate: 18% (<Currency amount={6930} symbolClassName="w-2 h-2" />) + 2% PG fee
                    </div>
                  </div>

                  {/* Accept / Reject Buttons */}
                  <div className="grid grid-cols-2 gap-2 mt-4">
                    <button
                      onClick={handleReject}
                      className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <XCircle className="w-4 h-4 text-rose-400" />
                      <span>Pass / Reject</span>
                    </button>

                    <button
                      onClick={handleAccept}
                      className="py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Accept Job</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-900 p-4 rounded-2xl border border-emerald-500/50 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-emerald-400">ACTIVE JOB #RFN-9812</span>
                    <span className="text-[10px] bg-emerald-500 text-slate-950 px-2 py-0.5 rounded font-bold">
                      IN TRANSIT
                    </span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] space-y-1">
                    <div className="text-slate-300 font-semibold">Customer: Ananya Sharma</div>
                    <div className="text-slate-400 text-[10px]">
                      Site: Flat 402, Prestige Elm, 100ft Rd, Indiranagar
                    </div>
                    <div className="text-amber-400 text-[10px] font-mono">
                      Ask Customer for 4-digit start OTP upon arrival.
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button className="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center justify-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Navigate (Google Maps)</span>
                    </button>
                    <button
                      onClick={() => setHasJob(false)}
                      className="px-3 py-2 rounded-lg bg-slate-800 text-slate-400 text-[10px]"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: IN-APP DIGITAL MEASUREMENT & QUOTATION GENERATOR */}
          {activePartnerTab === 'quote' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-white text-xs">Laser Room Measurement Sheet</span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Input room dimensions to compute exact sq.ft and generate instant client estimate.
                </p>

                {/* Rooms List */}
                <div className="mt-2.5 space-y-2">
                  {rooms.map((room, i) => (
                    <div key={i} className="bg-slate-950 p-2 rounded-lg border border-slate-800 text-[10px] space-y-1">
                      <div className="font-bold text-white flex justify-between">
                        <span>{room.name}</span>
                        <span className="text-amber-400">
                          {2 * (room.length + room.width) * room.height - room.windowsDeduction} sqft wall
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-1 text-slate-400">
                        <span>L: {room.length} ft</span>
                        <span>W: {room.width} ft</span>
                        <span>H: {room.height} ft</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-3 bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex justify-between text-xs font-bold">
                  <span className="text-slate-300">Total Net Wall Area:</span>
                  <span className="text-amber-400 font-mono">{totalWallSqFt} sq.ft</span>
                </div>

                {/* Paint Tier selector */}
                <div className="mt-3">
                  <span className="text-[11px] text-slate-300 block mb-1">Select Paint Tier:</span>
                  <div className="grid grid-cols-3 gap-1">
                    {(['economy', 'premium', 'luxury'] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => setSelectedBrandTier(t)}
                        className={`p-1.5 rounded text-[10px] capitalize border cursor-pointer ${
                          selectedBrandTier === t
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quote Result */}
                <div className="mt-3 pt-3 border-t border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-slate-400">Computed Quote Total:</span>
                    <div className="text-base font-bold text-emerald-400 font-mono">
                      ₹{quoteTotal.toLocaleString()}
                    </div>
                  </div>
                  <button className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[10px] flex items-center gap-1 cursor-pointer">
                    <span>Send to Client</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: MILESTONE WORK CHECKLIST & PROOF UPLOAD */}
          {activePartnerTab === 'milestones' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-white text-xs">Milestone Proof & Sign-Offs</span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Upload job site photos to unlock escrow tranches into your wallet.
                </p>

                <div className="mt-3 space-y-2.5">
                  {/* Stage 1 */}
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white text-[11px]">Stage 1: Material & Masking</span>
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.2 rounded font-bold">
                        VERIFIED & RELEASED (40%)
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">
                      Released into wallet: <strong className="text-emerald-400">₹15,400</strong>
                    </div>
                  </div>

                  {/* Stage 2 */}
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white text-[11px]">Stage 2: Putty & 1st Coat</span>
                      <span className="text-[9px] bg-amber-500/20 text-amber-400 border border-amber-500/40 px-1.5 py-0.2 rounded font-bold">
                        {milestone2Uploaded ? 'PENDING CLIENT APPROVAL' : 'WORK IN PROGRESS'}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      Escrow Tranche 2: <strong className="text-white">₹15,400</strong>
                    </p>

                    <button
                      onClick={() => setMilestone2Uploaded(true)}
                      className="mt-2 w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer border border-slate-700"
                    >
                      <Camera className="w-3.5 h-3.5 text-amber-400" />
                      <span>{milestone2Uploaded ? '✓ 4 Photos Submitted' : 'Upload Wall Photos'}</span>
                    </button>
                  </div>

                  {/* Stage 3 */}
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white text-[11px]">Stage 3: 2nd Coat & QA</span>
                      <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded font-bold">
                        LOCKED (20%)
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Escrow Tranche 3: ₹7,700 (Unlocks upon final customer signoff)
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PARTNER WALLET & PAYOUT LEDGER */}
          {activePartnerTab === 'wallet' && (
            <div className="space-y-3">
              <div className="bg-gradient-to-br from-slate-900 to-indigo-950/80 p-4 rounded-2xl border border-indigo-500/40">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                  Withdrawable Wallet Balance
                </span>
                <div className="text-2xl font-bold text-white font-mono mt-0.5">
                  <Currency amount={walletBalance} symbolClassName="w-5 h-5 mr-1" />
                </div>
                <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-amber-400" />
                  <span>Pending in ongoing escrow: <Currency amount={escrowPending} symbolClassName="w-2.5 h-2.5" /></span>
                </div>

                <button
                  onClick={() => {
                    setPayoutRequested(true);
                    setWalletBalance(0);
                    setTimeout(() => setPayoutRequested(false), 3000);
                  }}
                  className="mt-3 w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Request Instant IMPS Payout</span>
                </button>
              </div>

              {payoutRequested && (
                <div className="bg-emerald-950/80 border border-emerald-500/50 p-2.5 rounded-xl text-emerald-300 text-[10px] animate-pulse">
                  ✓ Transfer initiated: ₹14,850 credited to HDFC Bank A/c ending 4819 via IMPS.
                </div>
              )}

              {/* Transactions Ledger */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-white text-xs block mb-2">Recent Payout Ledger</span>
                <div className="space-y-2 text-[10px]">
                  <div className="bg-slate-950 p-2 rounded flex justify-between">
                    <div>
                      <div className="text-white font-semibold">Stage 1 Escrow Release #RFN-9812</div>
                      <div className="text-slate-500">Gross ₹19,250 - 18% Refine Fee</div>
                    </div>
                    <div className="text-emerald-400 font-mono font-bold">+₹15,400</div>
                  </div>

                  <div className="bg-slate-950 p-2 rounded flex justify-between">
                    <div>
                      <div className="text-white font-semibold">Instant Job Completed #RFN-9740</div>
                      <div className="text-slate-500">Tap leak repair (Plumbing)</div>
                    </div>
                    <div className="text-emerald-400 font-mono font-bold">+₹490</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: KYC VERIFICATION STATUS */}
          {activePartnerTab === 'kyc' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2.5">
                <span className="font-bold text-white text-xs">Partner Verification Checklist</span>

                <div className="space-y-2 text-[10px]">
                  <div className="bg-slate-950 p-2 rounded border border-emerald-500/40 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">1. Aadhaar ID & Digilocker OCR</div>
                      <div className="text-slate-400">UIDAI Verified • Ramesh Patel</div>
                    </div>
                    <span className="text-emerald-400 font-bold">✓ APPROVED</span>
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-emerald-500/40 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">2. Police Background Clearance</div>
                      <div className="text-slate-400">Karnataka State Police Certificate</div>
                    </div>
                    <span className="text-emerald-400 font-bold">✓ APPROVED</span>
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-emerald-500/40 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">3. Skill Trade Certification</div>
                      <div className="text-slate-400">Asian Paints Master Craftsman (Level 3)</div>
                    </div>
                    <span className="text-emerald-400 font-bold">✓ APPROVED</span>
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-emerald-500/40 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">4. Bank Account Penny Drop</div>
                      <div className="text-slate-400">HDFC Bank • A/c Verified for IMPS</div>
                    </div>
                    <span className="text-emerald-400 font-bold">✓ ACTIVE</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
