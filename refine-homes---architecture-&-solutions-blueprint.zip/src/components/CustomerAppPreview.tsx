import React, { useState } from 'react';
import {
  calculatePaintingEstimate,
  calculateQuickTaskPrice,
  calculateCleaningPrice,
  calculateApplianceRepairPrice,
  PaintingInput,
  QuickTaskInput,
  CleaningInput,
  ApplianceRepairInput,
} from '../utils/pricing';
import { Currency, RupeeIcon } from './Currency';
import {
  Paintbrush,
  Wrench,
  Sparkles,
  Tv,
  Clock,
  ShieldCheck,
  MapPin,
  PhoneCall,
  CheckCircle,
  AlertCircle,
  DollarSign,
  ChevronRight,
  User,
  Star,
  Check,
} from 'lucide-react';

interface CustomerAppPreviewProps {
  onSimulateDispatch?: (category: string, bookingDetails: any) => void;
  activeBooking?: any;
}

export const CustomerAppPreview: React.FC<CustomerAppPreviewProps> = ({
  onSimulateDispatch,
  activeBooking,
}) => {
  const [selectedVertical, setSelectedVertical] = useState<
    'painting' | 'quick-tasks' | 'cleaning' | 'appliance'
  >('painting');

  // 1. Painting State
  const [paintingInput, setPaintingInput] = useState<PaintingInput>({
    carpetAreaSqFt: 850,
    paintTier: 'premium',
    includeCeiling: true,
    primerCoats: 1,
    waterproofingSqFt: 150,
  });

  // 2. Quick Tasks State
  const [quickTaskInput, setQuickTaskInput] = useState<QuickTaskInput>({
    serviceType: 'plumbing',
    pricingMode: 'hourly',
    durationHours: 2,
    emergencyVisit: false,
    surgeMultiplier: 1.0,
  });

  // 3. Deep Cleaning State
  const [cleaningInput, setCleaningInput] = useState<CleaningInput>({
    homeType: '2bhk',
    packageType: 'deep_pro',
    addons: [{ id: 'balcony', name: 'Balcony Wash', price: 499 }],
    surgeMultiplier: 1.0,
  });

  // 4. Appliance State
  const [applianceInput, setApplianceInput] = useState<ApplianceRepairInput>({
    inspectionFee: 299,
    spareParts: [
      { partName: 'AC Contactor Relay', cost: 650 },
      { partName: 'Capacitor 45uF', cost: 350 },
    ],
    laborComplexityFee: 350,
  });

  const [bookingSuccessModal, setBookingSuccessModal] = useState(false);
  const [maskedCallActive, setMaskedCallActive] = useState(false);

  // Computations
  const paintingEstimate = calculatePaintingEstimate(paintingInput);
  const quickTaskPrice = calculateQuickTaskPrice(quickTaskInput);
  const cleaningPrice = calculateCleaningPrice(cleaningInput);
  const appliancePrice = calculateApplianceRepairPrice(applianceInput);

  const handleBookNow = () => {
    let details: any = {};
    if (selectedVertical === 'painting') {
      details = { type: 'MILESTONE_INSPECTION', vertical: 'Painting', amount: paintingEstimate.totalEstimate, milestones: paintingEstimate.milestones };
    } else if (selectedVertical === 'quick-tasks') {
      details = { type: 'INSTANT', vertical: 'Quick Tasks', amount: quickTaskPrice.totalAmount, hours: quickTaskInput.durationHours };
    } else if (selectedVertical === 'cleaning') {
      details = { type: 'INSTANT', vertical: 'Deep Cleaning', amount: cleaningPrice.totalAmount, package: cleaningInput.packageType };
    } else {
      details = { type: 'INSPECTION_PARTS', vertical: 'Appliance Repair', amount: appliancePrice.totalAmount };
    }

    if (onSimulateDispatch) {
      onSimulateDispatch(selectedVertical, details);
    }
    setBookingSuccessModal(true);
    setTimeout(() => setBookingSuccessModal(false), 3000);
  };

  return (
    <div className="flex flex-col items-center">
      {/* Mobile Device Frame Mockup */}
      <div className="w-[380px] h-[780px] bg-slate-950 rounded-[44px] border-4 border-slate-700 shadow-2xl overflow-hidden flex flex-col relative">
        {/* Mobile Speaker / Camera Island */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-5 bg-slate-900 rounded-full flex items-center justify-center z-30">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-800 mr-2" />
          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500/80" />
        </div>

        {/* Mobile App Header */}
        <div className="bg-slate-900 px-4 pt-8 pb-3 border-b border-slate-800 text-white shrink-0 z-20">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-400 font-semibold tracking-wider uppercase">
                Customer App • Flutter
              </span>
              <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                <MapPin className="w-3.5 h-3.5 text-rose-400" />
                <span>Indiranagar 100ft Rd, BLR</span>
              </div>
            </div>
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-amber-400">
              U
            </div>
          </div>

          {/* Vertical Selector Chips */}
          <div className="grid grid-cols-4 gap-1 mt-3">
            <button
              onClick={() => setSelectedVertical('painting')}
              className={`p-1.5 rounded-lg flex flex-col items-center text-[10px] transition-all cursor-pointer ${
                selectedVertical === 'painting'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Paintbrush className="w-3.5 h-3.5 mb-0.5" />
              <span>Painting</span>
            </button>
            <button
              onClick={() => setSelectedVertical('quick-tasks')}
              className={`p-1.5 rounded-lg flex flex-col items-center text-[10px] transition-all cursor-pointer ${
                selectedVertical === 'quick-tasks'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Wrench className="w-3.5 h-3.5 mb-0.5" />
              <span>Quick</span>
            </button>
            <button
              onClick={() => setSelectedVertical('cleaning')}
              className={`p-1.5 rounded-lg flex flex-col items-center text-[10px] transition-all cursor-pointer ${
                selectedVertical === 'cleaning'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 mb-0.5" />
              <span>Cleaning</span>
            </button>
            <button
              onClick={() => setSelectedVertical('appliance')}
              className={`p-1.5 rounded-lg flex flex-col items-center text-[10px] transition-all cursor-pointer ${
                selectedVertical === 'appliance'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Tv className="w-3.5 h-3.5 mb-0.5" />
              <span>Appliance</span>
            </button>
          </div>
        </div>

        {/* Scrollable Mobile App Body */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 bg-slate-950 text-white text-xs">
          {/* Active Job Tracker Banner if dispatched */}
          {activeBooking && (
            <div className="bg-gradient-to-r from-emerald-950/80 to-slate-900 p-3 rounded-xl border border-emerald-500/40 animate-pulse">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  Partner En Route ({activeBooking.status || 'ASSIGNED'})
                </span>
                <span className="text-[10px] bg-emerald-500 text-slate-950 px-1.5 py-0.2 rounded font-bold">
                  ETA 8 Mins
                </span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-slate-800 border border-emerald-500 flex items-center justify-center font-bold text-xs text-white">
                    RP
                  </div>
                  <div>
                    <div className="font-semibold text-white">Ramesh Patel (Pro)</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" /> 4.9 (240 jobs)
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setMaskedCallActive(!maskedCallActive)}
                  className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                >
                  <PhoneCall className="w-3 h-3" />
                  <span>Call (Masked)</span>
                </button>
              </div>

              {maskedCallActive && (
                <div className="mt-2 text-[10px] bg-slate-900 p-1.5 rounded border border-indigo-500/40 text-indigo-300">
                  Twilio Relay: Routing via bridge <strong>+91 80 4719 0288</strong> (Your private number is hidden).
                </div>
              )}

              <div className="mt-2 text-[10px] bg-slate-900/90 p-1.5 rounded border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Security Start OTP:</span>
                <span className="font-mono font-bold text-amber-400 text-xs">7492</span>
              </div>
            </div>
          )}

          {/* VERTICAL 1: HOME PAINTING & WALL CARE */}
          {selectedVertical === 'painting' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">Home Painting Spec</span>
                  <span className="text-[10px] text-amber-400 font-semibold">Milestone Escrow</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Laser wall inspection, digital measurement sheet & 3-stage escrow protection.
                </p>

                {/* Carpet Area Slider */}
                <div className="mt-3">
                  <div className="flex justify-between text-[11px] font-medium text-slate-300 mb-1">
                    <span>Carpet Area:</span>
                    <strong className="text-amber-400">{paintingInput.carpetAreaSqFt} sq.ft</strong>
                  </div>
                  <input
                    type="range"
                    min="300"
                    max="3000"
                    step="50"
                    value={paintingInput.carpetAreaSqFt}
                    onChange={(e) =>
                      setPaintingInput({ ...paintingInput, carpetAreaSqFt: Number(e.target.value) })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <div className="text-[10px] text-slate-500 flex justify-between">
                    <span>Wall area: {paintingEstimate.effectiveWallSqFt} sq.ft (3.2x multiplier)</span>
                  </div>
                </div>

                {/* Paint Quality Tier */}
                <div className="mt-3">
                  <label className="text-[11px] font-medium text-slate-300 block mb-1">
                    Paint Tier & Finish:
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { id: 'economy', name: 'Economy', rate: 14 },
                      { id: 'premium', name: 'Premium Pro', rate: 24 },
                      { id: 'luxury', name: 'Luxury Royal', rate: 38 },
                    ].map((tier) => (
                      <button
                        key={tier.id}
                        type="button"
                        onClick={() =>
                          setPaintingInput({ ...paintingInput, paintTier: tier.id as any })
                        }
                        className={`p-2 rounded-lg text-center border cursor-pointer ${
                          paintingInput.paintTier === tier.id
                            ? 'bg-amber-500/20 border-amber-500 text-white font-bold'
                            : 'bg-slate-800/60 border-slate-700/60 text-slate-400'
                        }`}
                      >
                        <div className="text-[11px]">{tier.name}</div>
                        <div className="text-[9px] text-amber-400/90 flex items-center justify-center">
                          <Currency amount={tier.rate} symbolClassName="w-2.5 h-2.5 mr-0.5" />/sqft
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Toggles */}
                <div className="mt-3 space-y-2 pt-2 border-t border-slate-800">
                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="text-[11px] text-slate-300">Include Ceiling Paint</span>
                    <input
                      type="checkbox"
                      checked={paintingInput.includeCeiling}
                      onChange={(e) =>
                        setPaintingInput({ ...paintingInput, includeCeiling: e.target.checked })
                      }
                      className="accent-amber-500 w-3.5 h-3.5"
                    />
                  </label>

                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-slate-300">Waterproofing Patch:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="0"
                        max="1000"
                        step="25"
                        value={paintingInput.waterproofingSqFt}
                        onChange={(e) =>
                          setPaintingInput({
                            ...paintingInput,
                            waterproofingSqFt: Number(e.target.value),
                          })
                        }
                        className="w-16 bg-slate-800 border border-slate-700 rounded px-1.5 py-0.5 text-right text-[11px] text-white"
                      />
                      <span className="text-[10px] text-slate-400">sqft</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3-Stage Milestone Escrow Box */}
              <div className="bg-slate-900/90 p-3 rounded-xl border border-indigo-500/40">
                <div className="flex items-center justify-between text-xs font-bold text-indigo-300 mb-2">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    3-Stage Milestone Escrow Protection
                  </span>
                  <Currency amount={paintingEstimate.totalEstimate} className="text-white text-sm" />
                </div>

                <div className="space-y-1.5 text-[10px]">
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-slate-200">Stage 1: Material Delivery (40%)</div>
                      <div className="text-slate-500">Released after paint tubs & masking verified</div>
                    </div>
                    <Currency
                      amount={paintingEstimate.milestones.stage1Material.amount}
                      className="font-bold text-amber-400"
                    />
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-slate-200">Stage 2: Putty & 1st Coat (40%)</div>
                      <div className="text-slate-500">Released after wall sanding & base coat check</div>
                    </div>
                    <Currency
                      amount={paintingEstimate.milestones.stage2BaseCoat.amount}
                      className="font-bold text-amber-400"
                    />
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-slate-200">Stage 3: Final QA Sign-off (20%)</div>
                      <div className="text-slate-500">Released only after customer inspection approval</div>
                    </div>
                    <Currency
                      amount={paintingEstimate.milestones.stage3FinalSignoff.amount}
                      className="font-bold text-emerald-400"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VERTICAL 2: QUICK TASKS */}
          {selectedVertical === 'quick-tasks' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-white text-xs">Quick Tasks (Plumbing / Electric / Carpentry)</span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Nearest verified pro auto-dispatched within 15-30 minutes.
                </p>

                {/* Subcategory */}
                <div className="grid grid-cols-3 gap-1.5 mt-3">
                  {['plumbing', 'electrical', 'carpentry'].map((task) => (
                    <button
                      key={task}
                      onClick={() =>
                        setQuickTaskInput({ ...quickTaskInput, serviceType: task as any })
                      }
                      className={`p-2 rounded-lg text-center capitalize border cursor-pointer ${
                        quickTaskInput.serviceType === task
                          ? 'bg-amber-500/20 border-amber-500 text-white font-bold'
                          : 'bg-slate-800/60 border-slate-700/60 text-slate-400'
                      }`}
                    >
                      {task}
                    </button>
                  ))}
                </div>

                {/* Mode: Hourly vs Fixed */}
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() =>
                      setQuickTaskInput({ ...quickTaskInput, pricingMode: 'hourly' })
                    }
                    className={`flex-1 p-2 rounded-lg border text-center cursor-pointer ${
                      quickTaskInput.pricingMode === 'hourly'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    Hourly Rate
                  </button>
                  <button
                    onClick={() =>
                      setQuickTaskInput({ ...quickTaskInput, pricingMode: 'fixed' })
                    }
                    className={`flex-1 p-2 rounded-lg border text-center cursor-pointer ${
                      quickTaskInput.pricingMode === 'fixed'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    Fixed Task
                  </button>
                </div>

                {quickTaskInput.pricingMode === 'hourly' && (
                  <div className="mt-3 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-300">Estimated Duration:</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            setQuickTaskInput({
                              ...quickTaskInput,
                              durationHours: Math.max(1, (quickTaskInput.durationHours || 1) - 1),
                            })
                          }
                          className="w-6 h-6 rounded bg-slate-800 text-white font-bold"
                        >
                          -
                        </button>
                        <span className="font-bold text-amber-400 text-xs">
                          {quickTaskInput.durationHours} Hours
                        </span>
                        <button
                          onClick={() =>
                            setQuickTaskInput({
                              ...quickTaskInput,
                              durationHours: (quickTaskInput.durationHours || 1) + 1,
                            })
                          }
                          className="w-6 h-6 rounded bg-slate-800 text-white font-bold"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <p className="text-[9px] text-slate-500 mt-1">
                      ₹299 for first hour, ₹199 each additional hour.
                    </p>
                  </div>
                )}

                <label className="mt-3 flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800 cursor-pointer">
                  <span className="text-[11px] text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-rose-400" />
                    Emergency 30-Min Priority Visit (+₹150)
                  </span>
                  <input
                    type="checkbox"
                    checked={quickTaskInput.emergencyVisit}
                    onChange={(e) =>
                      setQuickTaskInput({ ...quickTaskInput, emergencyVisit: e.target.checked })
                    }
                    className="accent-amber-500 w-3.5 h-3.5"
                  />
                </label>
              </div>

              {/* Price summary */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 text-[10px]">Estimated Price (inc. GST)</span>
                  <div className="text-base font-bold text-white">
                    ₹{quickTaskPrice.totalAmount.toLocaleString()}
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-semibold">
                  Instant Auto-Dispatch
                </span>
              </div>
            </div>
          )}

          {/* VERTICAL 3: DEEP CLEANING */}
          {selectedVertical === 'cleaning' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-white text-xs">Deep Cleaning & Pest Control</span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Flat-rate standardized packages with hospital-grade equipment.
                </p>

                {/* Home Type */}
                <div className="grid grid-cols-4 gap-1 mt-3">
                  {(['1bhk', '2bhk', '3bhk', '4bhk_villa'] as const).map((home) => (
                    <button
                      key={home}
                      onClick={() => setCleaningInput({ ...cleaningInput, homeType: home })}
                      className={`p-1.5 rounded-lg text-center uppercase border cursor-pointer ${
                        cleaningInput.homeType === home
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {home.replace('_', ' ')}
                    </button>
                  ))}
                </div>

                {/* Package Type */}
                <div className="mt-3 space-y-1.5">
                  {[
                    { id: 'classic', name: 'Classic Clean', desc: 'Floors, surfaces, dusting' },
                    { id: 'deep_pro', name: 'Deep Pro (Recommended)', desc: 'Kitchen degreasing, bathroom descaling' },
                    { id: 'move_in_out', name: 'Move-in / Move-out', desc: 'Full deep scrub + pest spray' },
                  ].map((pkg) => (
                    <button
                      key={pkg.id}
                      onClick={() => setCleaningInput({ ...cleaningInput, packageType: pkg.id as any })}
                      className={`w-full p-2 rounded-lg border text-left flex justify-between items-center cursor-pointer ${
                        cleaningInput.packageType === pkg.id
                          ? 'bg-amber-500/15 border-amber-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-300'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-[11px]">{pkg.name}</div>
                        <div className="text-[9px] text-slate-400">{pkg.desc}</div>
                      </div>
                      {cleaningInput.packageType === pkg.id && (
                        <Check className="w-3.5 h-3.5 text-amber-400" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price summary */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 text-[10px]">Flat Package Total</span>
                  <div className="text-base font-bold text-white">
                    ₹{cleaningPrice.totalAmount.toLocaleString()}
                  </div>
                </div>
                <span className="text-[10px] bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded font-semibold">
                  Fixed Transparent Price
                </span>
              </div>
            </div>
          )}

          {/* VERTICAL 4: APPLIANCE REPAIR */}
          {selectedVertical === 'appliance' && (
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-white text-xs">Appliance Repair</span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Inspection Fee ₹299 upfront + OEM spare parts approved in-app.
                </p>

                <div className="mt-3 bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-2">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">Doorstep Diagnostic Visit:</span>
                    <strong className="text-amber-400">₹299</strong>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">Technician Labor & Testing:</span>
                    <strong className="text-slate-200">₹{applianceInput.laborComplexityFee}</strong>
                  </div>

                  <div className="pt-2 border-t border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-1">
                      Identified Spare Parts (Approved by Customer):
                    </span>
                    {applianceInput.spareParts.map((part, i) => (
                      <div key={i} className="flex justify-between text-[10px] text-slate-300">
                        <span>• {part.partName}</span>
                        <span>₹{part.cost}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Price summary */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 text-[10px]">Total Service + Parts</span>
                  <div className="text-base font-bold text-white">
                    ₹{appliancePrice.totalAmount.toLocaleString()}
                  </div>
                </div>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded font-semibold">
                  30-Day Warranty
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Mobile Fixed Bottom CTA Bar */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 z-20 shrink-0">
          <button
            onClick={handleBookNow}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.98]"
          >
            <span>
              {selectedVertical === 'painting'
                ? 'Book Free Laser Survey & Quote'
                : 'Confirm Booking & Auto-Dispatch'}
            </span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Booking Confirmation Toast */}
        {bookingSuccessModal && (
          <div className="absolute inset-x-4 top-20 bg-emerald-600 text-white p-3 rounded-xl shadow-2xl flex items-center gap-2 z-40 animate-bounce">
            <CheckCircle className="w-5 h-5 shrink-0" />
            <div className="text-xs">
              <strong className="block">Order Dispatched to Radar!</strong>
              <span>Searching nearby verified partners...</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
