import React, { useState } from 'react';
import {
  Map,
  ShieldAlert,
  Layers,
  Users,
  CheckCircle,
  XCircle,
  TrendingUp,
  AlertTriangle,
  Sliders,
  DollarSign,
  Activity,
  FileText,
  Search,
  Filter,
} from 'lucide-react';

export const OpsDashboardPreview: React.FC = () => {
  const [opsTab, setOpsTab] = useState<'geofence' | 'catalog' | 'kyc-queue' | 'disputes'>('geofence');

  // Geofence zones state
  const [zones, setZones] = useState([
    { id: 'blr-indiranagar', city: 'Bengaluru', name: 'Indiranagar & Domlur (H3 Zone 8)', surge: 1.25, activePartners: 48, pendingJobs: 6, status: 'Active' },
    { id: 'blr-koramangala', city: 'Bengaluru', name: 'Koramangala & HSR Layout', surge: 1.40, activePartners: 62, pendingJobs: 11, status: 'Active' },
    { id: 'blr-whitefield', city: 'Bengaluru', name: 'Whitefield IT Corridor', surge: 1.00, activePartners: 35, pendingJobs: 2, status: 'Active' },
    { id: 'mum-bandra', city: 'Mumbai', name: 'Bandra West & Khar', surge: 1.30, activePartners: 54, pendingJobs: 8, status: 'Active' },
  ]);

  // KYC Onboarding Queue
  const [kycQueue, setKycQueue] = useState([
    {
      id: 'KYC-801',
      name: 'Sunil Kumar',
      category: 'Painting',
      phone: '+91 98201 44521',
      docType: 'Aadhaar + Asian Paints Level 2',
      status: 'PENDING_REVIEW',
      appliedAt: '12 mins ago',
    },
    {
      id: 'KYC-802',
      name: 'Mohammed Irfan',
      category: 'Plumbing',
      phone: '+91 98450 11982',
      docType: 'Aadhaar + Govt ITI Certificate',
      status: 'PENDING_REVIEW',
      appliedAt: '34 mins ago',
    },
    {
      id: 'KYC-803',
      name: 'Deepak Verma',
      category: 'Electrical',
      phone: '+91 99002 88319',
      docType: 'Aadhaar + Wireman License',
      status: 'PENDING_REVIEW',
      appliedAt: '1 hour ago',
    },
  ]);

  // Dispute Desk
  const [disputes, setDisputes] = useState([
    {
      id: 'DISP-401',
      bookingCode: 'RFN-8910',
      customer: 'Pooja Hegde',
      partner: 'Vikram Singh (Painter)',
      issue: 'Customer claims wall primer coat uneven; requests milestone 2 escrow hold',
      escrowLockedAmount: 18500,
      status: 'ESCROW_FROZEN',
      priority: 'High',
    },
    {
      id: 'DISP-402',
      bookingCode: 'RFN-9122',
      customer: 'Arun Nair',
      partner: 'Kishore Carpentry',
      issue: 'Door hinge alignment dispute after completion',
      escrowLockedAmount: 799,
      status: 'INVESTIGATING',
      priority: 'Medium',
    },
  ]);

  const handleUpdateSurge = (zoneId: string, newSurge: number) => {
    setZones(zones.map((z) => (z.id === zoneId ? { ...z, surge: newSurge } : z)));
  };

  const handleApproveKyc = (id: string) => {
    setKycQueue(kycQueue.filter((item) => item.id !== id));
  };

  const handleRejectKyc = (id: string) => {
    setKycQueue(kycQueue.filter((item) => item.id !== id));
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col h-[780px]">
      {/* Ops Header */}
      <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="font-bold text-white text-base">Refine Homes • Ops Mission Control</h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
              Admin Next.js
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Real-time geofence dispatching, dynamic surge levers, KYC verification desk & escrow dispute resolution.
          </p>
        </div>

        {/* Ops Navigation Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setOpsTab('geofence')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
              opsTab === 'geofence'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Map className="w-3.5 h-3.5" />
            <span>Geofence & Surge</span>
          </button>
          <button
            onClick={() => setOpsTab('kyc-queue')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
              opsTab === 'kyc-queue'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>KYC Queue ({kycQueue.length})</span>
          </button>
          <button
            onClick={() => setOpsTab('catalog')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
              opsTab === 'catalog'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Service Catalog</span>
          </button>
          <button
            onClick={() => setOpsTab('disputes')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
              opsTab === 'disputes'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>Disputes ({disputes.length})</span>
          </button>
        </div>
      </div>

      {/* Ops Content Area */}
      <div className="flex-1 overflow-y-auto p-5 bg-slate-950/70 space-y-5">
        {/* TAB 1: GEOFENCE & SURGE */}
        {opsTab === 'geofence' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block">Total Active Zones</span>
                <span className="text-xl font-bold text-white mt-1 block">4 Polygons</span>
                <span className="text-[10px] text-emerald-400">PostGIS H3 Index active</span>
              </div>
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block">Active Verified Pros Online</span>
                <span className="text-xl font-bold text-amber-400 mt-1 block">199 Partners</span>
                <span className="text-[10px] text-slate-500">Live GPS Heartbeats (60s)</span>
              </div>
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block">Unassigned Demand Queue</span>
                <span className="text-xl font-bold text-sky-400 mt-1 block">27 Bookings</span>
                <span className="text-[10px] text-slate-500">Avg radar match: 620ms</span>
              </div>
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block">Max Surge Multiplier</span>
                <span className="text-xl font-bold text-rose-400 mt-1 block">1.40x (Koramangala)</span>
                <span className="text-[10px] text-rose-300">High demand / rain alert</span>
              </div>
            </div>

            {/* Geofence Zones Table */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  City Geofence Polygons & Dynamic Surge Configuration
                </h4>
                <span className="text-xs text-slate-400">Adjust multiplier to balance supply/demand</span>
              </div>

              <div className="divide-y divide-slate-800/80">
                {zones.map((zone) => (
                  <div
                    key={zone.id}
                    className="p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:bg-slate-800/40 transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{zone.name}</span>
                        <span className="px-2 py-0.2 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                          {zone.city}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1 flex items-center gap-4">
                        <span>
                          Active Pros: <strong className="text-emerald-400">{zone.activePartners}</strong>
                        </span>
                        <span>
                          Pending Jobs: <strong className="text-amber-400">{zone.pendingJobs}</strong>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 w-full md:w-auto">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400">Surge Multiplier:</span>
                        <span className="text-sm font-bold text-amber-400 font-mono w-12 text-center">
                          {zone.surge.toFixed(2)}x
                        </span>
                      </div>

                      <input
                        type="range"
                        min="1.0"
                        max="2.5"
                        step="0.05"
                        value={zone.surge}
                        onChange={(e) => handleUpdateSurge(zone.id, parseFloat(e.target.value))}
                        className="w-32 accent-amber-500 cursor-pointer"
                      />

                      <button
                        onClick={() => handleUpdateSurge(zone.id, 1.0)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 cursor-pointer"
                      >
                        Reset 1.0x
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: KYC QUEUE */}
        {opsTab === 'kyc-queue' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="font-bold text-white text-sm">Partner Onboarding Verification Queue</h4>
                <p className="text-xs text-slate-400">Review Aadhaar OCR data and background certificates before granting job radar access.</p>
              </div>
              <span className="text-xs bg-amber-500/20 text-amber-400 border border-amber-500/40 px-2.5 py-1 rounded-lg font-bold">
                {kycQueue.length} Applications Awaiting Review
              </span>
            </div>

            <div className="space-y-3">
              {kycQueue.map((item) => (
                <div
                  key={item.id}
                  className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{item.name}</span>
                      <span className="text-[10px] bg-slate-800 text-amber-400 px-2 py-0.5 rounded font-bold">
                        {item.category}
                      </span>
                      <span className="text-[10px] text-slate-500">{item.appliedAt}</span>
                    </div>
                    <div className="text-xs text-slate-300">
                      Phone: <span className="font-mono text-slate-400">{item.phone}</span>
                    </div>
                    <div className="text-xs text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Submitted Documents: <strong className="text-white">{item.docType}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleRejectKyc(item.id)}
                      className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                    <button
                      onClick={() => handleApproveKyc(item.id)}
                      className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Approve & Unlock Dispatch</span>
                    </button>
                  </div>
                </div>
              ))}

              {kycQueue.length === 0 && (
                <div className="text-center py-12 text-slate-400 text-xs">
                  All partner onboarding applications have been verified and processed!
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: SERVICE CATALOG */}
        {opsTab === 'catalog' && (
          <div className="space-y-4">
            <h4 className="font-bold text-white text-sm">Dynamic Service Catalog & Pricing Matrix</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-amber-400 uppercase">Vertical 1: Painting & Wall Care</span>
                <div className="text-xs text-slate-300 space-y-1">
                  <div className="flex justify-between py-1 border-b border-slate-800">
                    <span>Economy Paint Tier (Tractor Emulsion)</span>
                    <strong className="text-white">₹14 / sq.ft wall</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800">
                    <span>Premium Pro Tier (Apcolite / Royale Glitz)</span>
                    <strong className="text-white">₹24 / sq.ft wall</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800">
                    <span>Luxury Royal Tier (PU & Venetian Stucco)</span>
                    <strong className="text-white">₹38 / sq.ft wall</strong>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Platform Commission</span>
                    <strong className="text-amber-400">18% Escrow Hold</strong>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-sky-400 uppercase">Vertical 2: Quick Tasks</span>
                <div className="text-xs text-slate-300 space-y-1">
                  <div className="flex justify-between py-1 border-b border-slate-800">
                    <span>Base Inspection / First 60 Mins</span>
                    <strong className="text-white">₹299</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800">
                    <span>Each Additional Hour</span>
                    <strong className="text-white">₹199 / hr</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800">
                    <span>Emergency Priority Slot (30-min SLA)</span>
                    <strong className="text-white">+₹150 surcharge</strong>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Platform Commission</span>
                    <strong className="text-sky-400">18% Direct Split</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: DISPUTES & ESCROW FREEZE */}
        {opsTab === 'disputes' && (
          <div className="space-y-4">
            <h4 className="font-bold text-white text-sm">Dispute Resolution Desk & Escrow Freeze</h4>
            <div className="space-y-3">
              {disputes.map((d) => (
                <div key={d.id} className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white text-xs">{d.id}</span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                        Booking: {d.bookingCode}
                      </span>
                    </div>
                    <span className="text-[10px] bg-rose-500/20 text-rose-400 border border-rose-500/40 px-2 py-0.5 rounded font-bold">
                      {d.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300">{d.issue}</p>

                  <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-800">
                    <span className="text-slate-400">
                      Escrow Tranche Locked: <strong className="text-amber-400 font-mono">₹{d.escrowLockedAmount.toLocaleString()}</strong>
                    </span>
                    <div className="flex gap-2">
                      <button className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-white">
                        Review Photo Proof
                      </button>
                      <button className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-[10px] text-white font-bold">
                        Arbitrate & Release
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
