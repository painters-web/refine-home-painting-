import React, { useState } from 'react';
import { CustomerAppPreview } from './CustomerAppPreview';
import { PartnerAppPreview } from './PartnerAppPreview';
import { OpsDashboardPreview } from './OpsDashboardPreview';
import { Smartphone, Monitor, Radio, ArrowRight, Zap, RefreshCw } from 'lucide-react';

export const SimulatorView: React.FC = () => {
  const [activeApp, setActiveApp] = useState<'customer' | 'partner' | 'ops'>('customer');
  const [activeBooking, setActiveBooking] = useState<any>(null);
  const [incomingJobAlert, setIncomingJobAlert] = useState<any>(null);

  const handleSimulateDispatch = (category: string, bookingDetails: any) => {
    const booking = {
      id: 'RFN-' + Math.floor(1000 + Math.random() * 9000),
      category,
      ...bookingDetails,
      status: 'ASSIGNED',
    };
    setActiveBooking(booking);
    setIncomingJobAlert(booking);
  };

  const handleAcceptJob = (job: any) => {
    if (activeBooking) {
      setActiveBooking({ ...activeBooking, status: 'IN_TRANSIT' });
    }
  };

  const handleResetSimulator = () => {
    setActiveBooking(null);
    setIncomingJobAlert(null);
  };

  return (
    <div className="space-y-6">
      {/* Simulator Control Header */}
      <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <h2 className="text-xl font-bold text-white">Live Refine Homes Ecosystem Simulator</h2>
            <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
              Tri-App Real-Time Sync
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-3xl">
            Experience how the 3 core applications interact: book a service in the <strong>Customer App</strong>, watch the <strong>Partner App</strong> radar ring with the 30s accept timer, and monitor spatial dispatch & surge pricing in the <strong>Ops Dashboard</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* App Switcher Tabs */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => setActiveApp('customer')}
              data-testid="switch-customer-app"
              aria-label="Switch to Customer App"
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeApp === 'customer'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Customer App</span>
            </button>
            <button
              onClick={() => setActiveApp('partner')}
              data-testid="switch-partner-app"
              aria-label="Switch to Partner App"
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeApp === 'partner'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Partner App</span>
            </button>
            <button
              onClick={() => setActiveApp('ops')}
              data-testid="switch-ops-dashboard"
              aria-label="Switch to Ops Dashboard"
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeApp === 'ops'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Ops Dashboard</span>
            </button>
          </div>

          <button
            onClick={handleResetSimulator}
            title="Reset Simulator State"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Simulator Viewport */}
      <div>
        {activeApp === 'customer' && (
          <div className="flex flex-col items-center py-4">
            <div className="mb-3 text-center">
              <span className="text-xs text-amber-400 font-semibold block">Customer View (Flutter SPA)</span>
              <span className="text-[11px] text-slate-400">
                Configure Painting, Quick Tasks, Cleaning, or Appliance Repair & click Book
              </span>
            </div>
            <CustomerAppPreview
              onSimulateDispatch={handleSimulateDispatch}
              activeBooking={activeBooking}
            />
          </div>
        )}

        {activeApp === 'partner' && (
          <div className="flex flex-col items-center py-4">
            <div className="mb-3 text-center">
              <span className="text-xs text-emerald-400 font-semibold block">Partner Pro View (Flutter SPA)</span>
              <span className="text-[11px] text-slate-400">
                Review 30s job radar alert, test digital laser quotation sheet, or request wallet payout
              </span>
            </div>
            <PartnerAppPreview
              onAcceptJob={handleAcceptJob}
              incomingJobAlert={incomingJobAlert}
            />
          </div>
        )}

        {activeApp === 'ops' && (
          <div className="py-2">
            <OpsDashboardPreview />
          </div>
        )}
      </div>
    </div>
  );
};
