import React, { useState } from 'react';
import {
  MVP_ROADMAP_SPRINTS,
  MVP_RISK_REGISTER,
  RoadmapSprint,
  SprintDeliverable,
} from '../data/roadmapData';
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Flag,
  Target,
  ArrowRight,
  ShieldAlert,
  ChevronDown,
  Filter,
} from 'lucide-react';

export const RoadmapView: React.FC = () => {
  const [selectedSprint, setSelectedSprint] = useState<RoadmapSprint>(MVP_ROADMAP_SPRINTS[0]);
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const categories = ['All', 'Backend', 'Customer App', 'Partner App', 'Admin & Ops', 'Infra & QA'];

  const filteredDeliverables =
    filterCategory === 'All'
      ? selectedSprint.deliverables
      : selectedSprint.deliverables.filter((d) => d.category === filterCategory);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">8 to 12 Week MVP Phased Implementation Roadmap</h2>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-3xl">
            A battle-tested sprint trajectory taking Refine Homes from zero to a live beta in 1 pilot metro city (Bengaluru / Mumbai) across 6 bi-weekly engineering sprints.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950 px-3.5 py-1.5 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400">Total Duration: </span>
            <strong className="text-amber-400">12 Weeks (6 Sprints)</strong>
          </div>
          <div className="bg-slate-950 px-3.5 py-1.5 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400">Pilot Cohort: </span>
            <strong className="text-emerald-400">150 Verified Pros</strong>
          </div>
        </div>
      </div>

      {/* Horizontal Sprint Trackers */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {MVP_ROADMAP_SPRINTS.map((sprint) => {
          const isSelected = selectedSprint.sprintNumber === sprint.sprintNumber;
          return (
            <button
              key={sprint.sprintNumber}
              onClick={() => setSelectedSprint(sprint)}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                isSelected
                  ? 'bg-amber-500/15 border-amber-500 shadow-md text-white'
                  : 'bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-amber-400">Sprint {sprint.sprintNumber}</span>
                <span className="text-[10px] text-slate-400">{sprint.weeks}</span>
              </div>
              <div className="text-xs font-semibold text-white mt-1 line-clamp-1">{sprint.theme}</div>
              <div className="text-[10px] text-slate-400 mt-2 flex items-center gap-1">
                <span>{sprint.deliverables.length} Deliverables</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Sprint Deep Dive Container */}
      <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-slate-950">
                Sprint {selectedSprint.sprintNumber} • {selectedSprint.weeks}
              </span>
              <h3 className="text-lg font-bold text-white">{selectedSprint.theme}</h3>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">{selectedSprint.objective}</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 max-w-sm">
            <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
              <Target className="w-3.5 h-3.5" /> Key Success Metric (Exit Gate)
            </span>
            <p className="text-xs text-slate-200 mt-1">{selectedSprint.kpiMilestone}</p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Workstream:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                filterCategory === cat
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Deliverables Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredDeliverables.map((deliv, idx) => (
            <div
              key={idx}
              className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-amber-400/90 tracking-wider">
                    {deliv.category}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      deliv.status === 'Completed'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : deliv.status === 'In Progress'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {deliv.status}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-white mt-1">{deliv.title}</h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{deliv.description}</p>
              </div>

              <div className="pt-2 border-t border-slate-900 text-[10px] text-slate-500 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>Production Acceptance Criteria Defined</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Risk Register & Mitigation Strategy */}
      <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <h3 className="text-base font-bold text-white">MVP Risk Register & Mitigation Controls</h3>
          </div>
          <span className="text-xs text-slate-400">Architectural safeguards against failure modes</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 font-semibold">Risk Identifier & Event</th>
                <th className="py-2.5 px-3 font-semibold">Severity</th>
                <th className="py-2.5 px-3 font-semibold">Probability</th>
                <th className="py-2.5 px-3 font-semibold">Engineering & Product Mitigation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {MVP_RISK_REGISTER.map((risk) => (
                <tr key={risk.id} className="hover:bg-slate-800/30">
                  <td className="py-3 px-3 font-medium text-white">
                    <span className="font-mono text-amber-400 mr-2">[{risk.id}]</span>
                    {risk.risk}
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        risk.severity === 'High'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300'
                      }`}
                    >
                      {risk.severity}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-400">{risk.probability}</td>
                  <td className="py-3 px-3 text-slate-300 text-xs leading-relaxed">{risk.mitigation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
