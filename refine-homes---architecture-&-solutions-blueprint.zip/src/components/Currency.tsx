import React from 'react';

interface CurrencyProps {
  amount: number | string;
  className?: string;
  symbolClassName?: string;
}

export const RupeeIcon: React.FC<{ className?: string }> = ({ className = 'w-3 h-3 inline-block -mt-0.5' }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M6 3h12" />
    <path d="M6 8h12" />
    <path d="M6 13l8.5 8" />
    <path d="M6 13h3a4 4 0 0 0 0-8" />
  </svg>
);

export const Currency: React.FC<CurrencyProps> = ({ amount, className = '', symbolClassName = 'w-3.5 h-3.5 mr-0.5 inline-block -mt-0.5' }) => {
  const formatted = typeof amount === 'number' ? amount.toLocaleString() : amount;
  return (
    <span className={`inline-flex items-center font-mono ${className}`}>
      <RupeeIcon className={symbolClassName} />
      <span>{formatted}</span>
    </span>
  );
};
