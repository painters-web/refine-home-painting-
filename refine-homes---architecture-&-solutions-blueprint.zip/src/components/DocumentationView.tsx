import React, { useState } from 'react';
import {
  FileText,
  Copy,
  Check,
  Printer,
  Download,
  ShieldCheck,
  Layers,
  Smartphone,
  Database,
  Calendar,
  GitBranch,
} from 'lucide-react';

export const DocumentationView: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const fullMarkdownSpec = `# Refine Homes: Technical Architecture & Product Implementation Plan
**Role:** Principal Solutions Architect & Product Manager  
**Platform:** Multi-Category On-Demand Home Services (Urban Company Model)  
**Target Brand:** Refine Homes  
**Version:** 1.0.0-PROD-SPEC  
**Date:** October 2026  

---

## 1. Executive Summary & Product Ecosystem
Refine Homes is an enterprise on-demand home care ecosystem engineered to solve trust, pricing ambiguity, and operational latency in residential services. 

### Multi-Vertical Catalog Strategy
1. **Home Painting & Wall Care:** High-value, long-cycle vertical requiring detailed laser measurement, wall diagnostic (moisture/sanding), custom paint tier selection, and 3-stage milestone escrow protection.
2. **Quick Tasks (Plumbing, Electrical, Carpentry):** High-velocity, on-demand jobs operating on hourly rates (₹299 base first hr + ₹199/hr) or fixed transparent task rates with 30-min SLA auto-dispatch.
3. **Deep Cleaning & Pest Control:** Standardized package-based flat pricing (1BHK to 4BHK/Villa) with add-on upsells and hospital-grade equipment.
4. **Appliance Repair:** Inspection fee model (₹299 upfront diagnostic visit) + dynamic digital approval for OEM spare parts and labor complexity fees.

---

## 2. Core Applications Architecture

### 2.1 Customer App (Flutter / React Native)
- **Framework:** Flutter for 60fps canvas performance and dynamic form schemas.
- **Key Modules:**
  - Dynamic Category Discovery Grid with localized promotional carousels.
  - Multi-Vertical Form Intake (e.g., room sliders, paint finish, addon checklists).
  - Real-Time Partner Tracking on Google Maps with route polyline interpolation.
  - Twilio / Exotel Virtual Call Masking (relay proxy protecting user mobile number).
  - Razorpay / Stripe Split Payment Checkout (UPI, Cards, Netbanking).
  - Milestone Approval Modal with digital signature & photo inspection viewer.
  - Post-service double-blind ratings and multi-attribute reviews.

### 2.2 Professional Partner App (Flutter)
- **Key Modules:**
  - Digital KYC Onboarding: Aadhaar OCR (Digilocker API), Police Verification Certificate upload, Skill Trade Assessment.
  - 30-Second Job Dispatch Radar: High-priority FCM push alert with countdown timer, distance, estimated gross/net earnings.
  - Digital Laser Measurement & Quote Sheet Generator: Room length, width, height, window deduction calculator; generates customer quote on-site.
  - Milestone Progress Checklist: Pre-requisite camera capture of before/after photos before requesting customer escrow unlock.
  - Partner Digital Wallet & IMPS Payout: Real-time balance ledger, pending escrow holds, lifetime earnings, and instant bank disbursement request.

### 2.3 Admin & Ops Mission Control (React / Next.js)
- **Key Modules:**
  - City & Spatial Geofence Polygon Manager: PostGIS boundary configuration, partner density heatmap, unassigned demand monitor.
  - Dynamic Surge Multiplier Controls: Algorithmic or manual surge levers (1.0x to 2.5x) based on localized weather or festival demand.
  - Partner KYC Verification Queue: Admin approval/rejection desk with audit trails.
  - Milestone Dispute Resolution Desk: Customer dissatisfaction ticket escalation, temporary escrow freeze, and mediator arbitration tools.
  - Dynamic Service Catalog & Pricing Matrix: Configurable base prices, hourly increments, and spare parts catalog.

---

## 3. Technical Architecture & Distributed Stack

### 3.1 Technology Matrix
- **Mobile Frontend:** Flutter (Dart)
- **Admin Frontend:** React 19 / Next.js with Tailwind CSS
- **API Gateway:** Kong / Envoy Gateway (Go/Lua) with JWT claim enrichment & rate limiting
- **Backend Microservices:** Node.js (NestJS) + Go (Golang for high-throughput spatial dispatch)
- **Primary Relational DB:** PostgreSQL 16 with PostGIS extension (ACID compliant)
- **Cache & Geolocation:** Redis Cluster 7 (Native \`GEOADD\`/\`GEORADIUS\` and Redlock distributed mutex)
- **Event Bus:** Apache Kafka / RabbitMQ for asynchronous booking lifecycle events
- **Storage:** AWS S3 Private Buckets with CloudFront CDN & Pre-signed temporary URLs (TTL 15 mins)
- **Third-Party APIs:** Razorpay Route / Stripe Connect, Google Maps Platform, Twilio / Exotel Voice Proxy, FCM.

---

## 4. Service Booking Flow Logic & State Machines

### 4.1 Instant Booking Flow (Plumbing, Cleaning, Appliance)
\`\`\`
[Customer App] Requests slot & address
      │
      ▼
[API Gateway] Validates JWT & sends to Dispatch Service
      │
      ▼
[Dispatch Engine] Queries Redis GEO within 8km radius (H3 Resolution 8)
      │
      ▼
[Redlock Mutex] Locks candidate partner for 30 seconds
      │
      ▼
[Partner App] Rings with 30-sec audio alert & earnings breakdown
      ├── [Accepted] ──► Sockets connected ──► Start OTP verified ──► Work executed ──► Split payout
      └── [Timeout/Reject] ──► Lock released ──► Cascades to Candidate 2
\`\`\`

### 4.2 Milestone & Inspection Flow (Home Painting & Waterproofing)
\`\`\`
[Customer] Books Site Survey
      │
      ▼
[Master Painter] Arrives with laser distance meter & conducts diagnostic
      │
      ▼
[In-App Quotation Generator] Computes wall sq.ft (3.2x multiplier) & paint tier rates
      │
      ▼
[Customer App] Customer reviews digital quote & signs off
      │
      ▼
[Payment Escrow] 40% Stage 1 Deposit Captured into Escrow Account
      │
      ▼
[Stage 1 Execution] Materials delivered & floors masked ──► Photo proof ──► 40% Released
      │
      ▼
[Stage 2 Execution] Surface putty, primer & 1st coat ──► Photo proof ──► 40% Released
      │
      ▼
[Stage 3 Execution] Final coat, touch-ups & customer QA walk-through ──► Final 20% Released
      │
      ▼
[Settlement] Refine Homes 18% take-rate recorded; Partner net credited to Wallet
\`\`\`

---

## 5. PostgreSQL Production Schema Essentials
- **users:** id (UUID), phone, full_name, email, role (CUSTOMER, PARTNER, ADMIN).
- **partners:** id (UUID), user_id, category_id, kyc_status, rating_avg, current_location (GEOMETRY Point).
- **service_categories:** id (UUID), slug, name, pricing_model, base_commission_rate (18%).
- **services:** id (UUID), category_id, title, base_price, price_unit, dynamic_form_schema (JSONB).
- **geofence_zones:** id (UUID), city, boundary (GEOMETRY Polygon), surge_multiplier (1.0 to 3.0).
- **bookings:** id (UUID), booking_code, user_id, service_id, partner_id, status, scheduled_date, site_location, total_amount, start_otp, completion_otp.
- **quotations:** id (UUID), booking_id, partner_id, wall_area_sqft, paint_tier, parts_breakdown (JSONB), grand_total.
- **milestones:** id (UUID), booking_id, stage_number (1,2,3), amount, percentage (40,40,20), status, proof_images (JSONB).
- **payments:** id (UUID), booking_id, gateway_transaction_id, amount, escrow_status, platform_commission, partner_net_share.
- **wallets:** id (UUID), partner_id, available_balance, pending_escrow_balance, lifetime_earnings.
- **reviews:** id (UUID), booking_id, user_id, partner_id, rating_score (1-5), comment, aspect_tags (JSONB).

---

## 6. 8 to 12 Week MVP Phased Implementation Roadmap
- **Sprint 1 (Weeks 1-2):** Core Engine, PostgreSQL/PostGIS schemas, Redis GEO setup, Auth microservice.
- **Sprint 2 (Weeks 3-4):** Partner App shell, Aadhaar KYC pipeline, Admin KYC approval desk, Bank account verification.
- **Sprint 3 (Weeks 5-6):** Customer App multi-vertical catalog, Instant booking auto-dispatch engine, dynamic pricing matrices.
- **Sprint 4 (Weeks 7-8):** Partner digital quote builder, 3-stage milestone escrow engine, Razorpay split payments.
- **Sprint 5 (Weeks 9-10):** Live WebSocket partner GPS tracking, Twilio masked telephony relay, Ops surge & dispute center.
- **Sprint 6 (Weeks 11-12):** Concurrency load testing, partner cohort training (150 pros), closed beta launch in 1 metro city.
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullMarkdownSpec);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Full Architecture & Product Specification</h2>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Complete executive document ready for engineering hand-off, leadership review, and RFC sign-off.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Full Markdown!' : 'Copy Markdown PRD'}</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Formatted Technical Document Viewer */}
      <div className="bg-slate-900 rounded-2xl p-8 border border-slate-800 shadow-xl text-slate-200 space-y-8 max-w-5xl mx-auto leading-relaxed">
        {/* Document Title Header */}
        <div className="border-b border-slate-800 pb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider mb-3">
            Principal Solutions Architect • RFC 001
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Refine Homes: Multi-Category On-Demand Home Services Platform
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            Complete Technical Architecture, Multi-App Ecosystem, Booking State Logic, Database DDL & 12-Week MVP Delivery Roadmap.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs font-mono text-slate-400">
            <div>Author: Solutions Architect</div>
            <div>Brand: Refine Homes</div>
            <div>Model: Urban Company Scale</div>
            <div>Status: Approved for MVP</div>
          </div>
        </div>

        {/* Section 1 */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <span className="text-amber-400">1.</span> Platform Ecosystem & Core Apps
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h3 className="font-bold text-white text-sm flex items-center gap-1.5 text-amber-400">
                <Smartphone className="w-4 h-4" /> Customer App (Flutter)
              </h3>
              <p className="text-slate-300">
                Built with Flutter for high-performance canvas rendering and unified Android/iOS parity. Houses the category grid across all 4 verticals:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                <li>Dynamic intake forms per vertical</li>
                <li>Live partner GPS tracking on map</li>
                <li>In-app Twilio masked phone bridge</li>
                <li>Digital quotation review & signature</li>
                <li>Split payment checkout (Razorpay/Stripe)</li>
              </ul>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h3 className="font-bold text-white text-sm flex items-center gap-1.5 text-emerald-400">
                <Smartphone className="w-4 h-4" /> Partner App (Flutter)
              </h3>
              <p className="text-slate-300">
                Designed for field service professionals with high legibility and offline capabilities:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                <li>Aadhaar OCR & police verification KYC</li>
                <li>30-second job dispatch radar auction</li>
                <li>Laser room measurement sheet generator</li>
                <li>Milestone photo proof submission</li>
                <li>Wallet ledger & instant IMPS bank payout</li>
              </ul>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h3 className="font-bold text-white text-sm flex items-center gap-1.5 text-indigo-400">
                <Layers className="w-4 h-4" /> Admin & Ops (Next.js)
              </h3>
              <p className="text-slate-300">
                Central command center for regional operations managers:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                <li>City polygon geofence manager (PostGIS)</li>
                <li>Dynamic surge pricing multiplier overrides</li>
                <li>Partner onboarding verification queue</li>
                <li>Dispute escalation desk & escrow freeze</li>
                <li>Dynamic pricing catalog editor</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Section 2 */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <span className="text-amber-400">2.</span> Technical Architecture & Tech Stack Rationale
          </h2>

          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 text-xs space-y-3">
            <p className="text-slate-300">
              The platform utilizes an asynchronous, event-driven microservices architecture partitioned by domain boundaries:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="font-bold text-white">Edge & Microservices:</div>
                <ul className="list-disc list-inside text-slate-400 space-y-1">
                  <li><strong>Kong API Gateway:</strong> JWT validation, Redis rate limits, SSL termination.</li>
                  <li><strong>Auth Service (NestJS):</strong> Phone OTP via Exotel/Twilio, refresh token rotation.</li>
                  <li><strong>Dispatch Engine (Go):</strong> High-frequency Redis GEO queries, Redlock 30s mutex.</li>
                  <li><strong>Booking Service (NestJS):</strong> State machines for Instant and Milestone workflows.</li>
                  <li><strong>Payment Service (Go/NestJS):</strong> Razorpay Route / Stripe Connect split escrow.</li>
                </ul>
              </div>

              <div className="space-y-2">
                <div className="font-bold text-white">Data & Messaging:</div>
                <ul className="list-disc list-inside text-slate-400 space-y-1">
                  <li><strong>PostgreSQL 16 + PostGIS:</strong> Primary ACID storage for wallets, bookings, and polygon zones.</li>
                  <li><strong>Redis Cluster 7:</strong> Sub-millisecond partner coordinate streaming, job claim locks.</li>
                  <li><strong>Apache Kafka / RabbitMQ:</strong> Decoupled event topics for async pipelines.</li>
                  <li><strong>AWS S3 + CloudFront:</strong> Pre-signed temporary URLs for KYC and inspection media.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3 */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <span className="text-amber-400">3.</span> Multi-Vertical Service Booking Flow Logic
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h3 className="font-bold text-white text-sm text-sky-400">
                Instant Booking (Plumbing, Cleaning, Appliance)
              </h3>
              <p className="text-slate-300">
                1. Order placement triggers immediate Geohash proximity search in Redis GEO (8km radius).
              </p>
              <p className="text-slate-300">
                2. Distributed Redlock locks the highest ranked candidate for 30 seconds.
              </p>
              <p className="text-slate-300">
                3. Partner app plays audio alert. If accepted, customer receives ETA and start OTP. If 30s elapses, job cascades to next nearest pro.
              </p>
              <p className="text-slate-300">
                4. On completion OTP entry, funds split automatically (80% net partner, 18% Refine Homes take rate, 2% PG).
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h3 className="font-bold text-white text-sm text-amber-400">
                Milestone Booking (Painting & Waterproofing)
              </h3>
              <p className="text-slate-300">
                1. Free laser site survey booked; Master Painter takes digital wall dimensions and moisture readings.
              </p>
              <p className="text-slate-300">
                2. Digital quote generated in-app with 3 paint tiers (Economy, Premium, Luxury).
              </p>
              <p className="text-slate-300">
                3. Customer signs off and locks 40% Stage 1 funds into Escrow holding account.
              </p>
              <p className="text-slate-300">
                4. Tranche 1 (40% Material) & Tranche 2 (40% Prep) are verified via photo proof. Tranche 3 (20% Final Signoff) releases only upon customer QA satisfaction.
              </p>
            </div>
          </div>
        </section>

        {/* Section 4 */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <span className="text-amber-400">4.</span> 8-12 Week Phased MVP Delivery Plan
          </h2>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="font-bold text-amber-400 block">Weeks 1 - 4: Foundation & KYC</span>
                <p className="text-slate-400 text-[11px] mt-1">
                  Core PostgreSQL/PostGIS schemas, Redis geohashing, Partner App shell, Aadhaar OCR pipeline, Admin KYC approval queue.
                </p>
              </div>

              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="font-bold text-amber-400 block">Weeks 5 - 8: Multi-Vertical & Escrow</span>
                <p className="text-slate-400 text-[11px] mt-1">
                  Customer App with 4 verticals, Instant auto-dispatch radar, partner laser measurement tool, 3-stage milestone escrow engine.
                </p>
              </div>

              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="font-bold text-amber-400 block">Weeks 9 - 12: Real-Time & Pilot Beta</span>
                <p className="text-slate-400 text-[11px] mt-1">
                  WebSocket GPS tracking, Twilio masked telephony relay, Ops surge levers, partner cohort training, and pilot launch in 1 metro city.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Sign-off footer */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center text-xs text-slate-400">
          <div>Refine Homes Solutions Architecture &bull; Confidential & Proprietary</div>
          <div className="mt-2 sm:mt-0 font-mono text-amber-400">Approved for Engineering Build</div>
        </div>
      </div>
    </div>
  );
};
