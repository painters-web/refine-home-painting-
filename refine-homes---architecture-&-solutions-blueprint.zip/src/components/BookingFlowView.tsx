import React, { useState } from 'react';
import {
  canTransitionInstantState,
  canTransitionMilestoneState,
  InstantBookingState,
  MilestoneBookingState,
} from '../utils/bookingStateMachine';
import {
  GitBranch,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  Shield,
  Zap,
  RotateCcw,
  Play,
  Layers,
  Database,
  Radio,
} from 'lucide-react';

export const BookingFlowView: React.FC = () => {
  const [activeFlowType, setActiveFlowType] = useState<'instant' | 'milestone'>('milestone');

  // Interactive step runner for Instant flow
  const instantSteps: Array<{
    state: InstantBookingState;
    title: string;
    actor: 'Customer' | 'Dispatch Engine' | 'Partner' | 'Escrow Service';
    description: string;
    dbTable: string;
    eventTopic: string;
    sla: string;
  }> = [
    {
      state: 'REQUESTED',
      title: '1. Customer Places Order',
      actor: 'Customer',
      description: 'Customer selects service (e.g. 2BHK Deep Cleaning), enters location GPS, and confirms slot.',
      dbTable: 'bookings (status: REQUESTED)',
      eventTopic: 'booking.created',
      sla: 'Immediate',
    },
    {
      state: 'MATCHING_RADAR',
      title: '2. Redis Geohash Proximity & Lock',
      actor: 'Dispatch Engine',
      description: 'Go dispatch service runs `GEORADIUS` on active partners within 8km. Acquires 30-sec Redlock for candidate 1.',
      dbTable: 'Redis GEO & Redlock (TTL: 30s)',
      eventTopic: 'dispatch.radar_broadcast',
      sla: '< 800ms',
    },
    {
      state: 'PARTNER_ASSIGNED',
      title: '3. Partner Accepts via 30s Radar',
      actor: 'Partner',
      description: 'Partner device rings with high-priority FCM push. Partner accepts within 30s timer. Redlock claimed.',
      dbTable: 'bookings (partner_id, status: PARTNER_ASSIGNED)',
      eventTopic: 'partner.assigned',
      sla: '< 30 seconds',
    },
    {
      state: 'EN_ROUTE',
      title: '4. Live GPS Tracking & Masked Proxy',
      actor: 'Partner',
      description: 'Socket.io streams partner lat/long at 60Hz. Customer calls partner via Twilio masked virtual relay number.',
      dbTable: 'partners (current_lat, current_lon)',
      eventTopic: 'partner.location_stream',
      sla: 'ETA 15-30 mins',
    },
    {
      state: 'ARRIVED',
      title: '5. Site Arrival & Start OTP Verification',
      actor: 'Partner',
      description: 'Partner arrives at customer doorstep. Customer provides 4-digit security OTP to verify identity and unlock start.',
      dbTable: 'bookings (start_otp_verified: true)',
      eventTopic: 'job.started',
      sla: 'Doorstep check',
    },
    {
      state: 'WORK_STARTED',
      title: '6. Service Execution',
      actor: 'Partner',
      description: 'Standardized checklist performed using Refine Homes certified tools.',
      dbTable: 'bookings (status: WORK_STARTED)',
      eventTopic: 'job.in_progress',
      sla: '60 - 180 mins',
    },
    {
      state: 'COMPLETED',
      title: '7. Completion OTP & Automated Payout Split',
      actor: 'Escrow Service',
      description: 'Completion OTP entered. Razorpay/Stripe split releases: 80% to partner wallet, 18% to Refine Homes take rate, 2% PG.',
      dbTable: 'payments, wallets, reviews',
      eventTopic: 'booking.completed',
      sla: 'Real-time settlement',
    },
  ];

  // Interactive step runner for Milestone flow
  const milestoneSteps: Array<{
    state: MilestoneBookingState;
    title: string;
    actor: 'Customer' | 'Inspector' | 'Partner' | 'Escrow Ledger';
    description: string;
    dbTable: string;
    eventTopic: string;
    sla: string;
  }> = [
    {
      state: 'LEAD_CREATED',
      title: '1. Lead Generated & Survey Booked',
      actor: 'Customer',
      description: 'Customer requests Home Painting inspection. Selects home type and preferred site survey slot.',
      dbTable: 'bookings (type: MILESTONE_INSPECTION)',
      eventTopic: 'inspection.lead_created',
      sla: 'Immediate',
    },
    {
      state: 'SITE_VISIT_SCHEDULED',
      title: '2. Master Inspector Assigned',
      actor: 'Inspector',
      description: 'Certified Refine Homes painting consultant assigned to conduct laser wall measurement on-site.',
      dbTable: 'bookings (inspector_id, status: SCHEDULED)',
      eventTopic: 'inspection.partner_assigned',
      sla: 'Within 2 hours',
    },
    {
      state: 'INSPECTION_COMPLETED',
      title: '3. Laser Measurement & Wall Diagnostic',
      actor: 'Inspector',
      description: 'Inspector inputs room-by-room dimensions, moisture readings, and recommended primer/putty coats.',
      dbTable: 'quotations (wall_area_sqft, moisture_levels)',
      eventTopic: 'inspection.data_submitted',
      sla: 'Doorstep visit (~45 mins)',
    },
    {
      state: 'ESTIMATE_PENDING_APPROVAL',
      title: '4. Digital Estimate Generated in App',
      actor: 'Inspector',
      description: 'System automatically compiles material + labor quote with 3 brand tiers (Economy, Premium, Luxury).',
      dbTable: 'quotations (status: SUBMITTED)',
      eventTopic: 'quotation.sent_to_customer',
      sla: 'Instantaneous calculation',
    },
    {
      state: 'ESTIMATE_APPROVED',
      title: '5. Customer Approves & Stage 1 Escrow Locked',
      actor: 'Customer',
      description: 'Customer signs digital contract. 40% Stage 1 funds captured and held in safe Escrow holding account.',
      dbTable: 'milestones (stage: 1, status: LOCKED_ESCROW)',
      eventTopic: 'payment.escrow_locked',
      sla: 'Client decision',
    },
    {
      state: 'STAGE1_VERIFIED',
      title: '6. Stage 1: Materials & Masking Verified',
      actor: 'Partner',
      description: 'Paint tubs delivered, floors/furniture masked with plastic sheets. Photos submitted -> Customer approves -> 40% released.',
      dbTable: 'milestones (stage: 1, status: VERIFIED_RELEASED)',
      eventTopic: 'milestone.stage1_released',
      sla: 'Day 1 - 2',
    },
    {
      state: 'STAGE2_VERIFIED',
      title: '7. Stage 2: Primer, Putty & 1st Coat Complete',
      actor: 'Partner',
      description: 'Surface sanded, primer applied, base coat completed. Photo proof submitted -> Customer releases Stage 2 (40%).',
      dbTable: 'milestones (stage: 2, status: VERIFIED_RELEASED)',
      eventTopic: 'milestone.stage2_released',
      sla: 'Day 3 - 5',
    },
    {
      state: 'JOB_COMPLETED_SETTLED',
      title: '8. Stage 3: Final Finish & Quality Inspection Sign-off',
      actor: 'Escrow Ledger',
      description: '2nd coat applied, tape unmasked, site deep cleaned. Customer conducts walk-through sign-off. Final 20% released.',
      dbTable: 'payments, wallets, reviews (1-5 stars)',
      eventTopic: 'job.fully_settled',
      sla: '100% Satisfaction SLA',
    },
  ];

  const [currentInstantIndex, setCurrentInstantIndex] = useState(0);
  const [currentMilestoneIndex, setCurrentMilestoneIndex] = useState(0);

  const activeSteps = activeFlowType === 'instant' ? instantSteps : milestoneSteps;
  const currentIndex = activeFlowType === 'instant' ? currentInstantIndex : currentMilestoneIndex;

  const handleNextStep = () => {
    if (activeFlowType === 'instant') {
      if (currentInstantIndex < instantSteps.length - 1) {
        setCurrentInstantIndex(currentInstantIndex + 1);
      }
    } else {
      if (currentMilestoneIndex < milestoneSteps.length - 1) {
        setCurrentMilestoneIndex(currentMilestoneIndex + 1);
      }
    }
  };

  const handleResetFlow = () => {
    if (activeFlowType === 'instant') {
      setCurrentInstantIndex(0);
    } else {
      setCurrentMilestoneIndex(0);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Service Booking Flow Logic & State Machines</h2>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-3xl">
            Refine Homes runs two distinct lifecycle patterns: <strong>Instant Auto-Allocation</strong> for urgent/standard jobs (Plumbing, Cleaning) and <strong>3-Stage Milestone Escrow</strong> for high-value inspection jobs (Painting, Waterproofing).
          </p>
        </div>

        {/* Toggle between Instant and Milestone */}
        <div className="bg-slate-950 p-1.5 rounded-xl border border-slate-800 flex items-center gap-1">
          <button
            onClick={() => setActiveFlowType('milestone')}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
              activeFlowType === 'milestone'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Milestone / Painting Flow (3-Stage Escrow)</span>
          </button>

          <button
            onClick={() => setActiveFlowType('instant')}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
              activeFlowType === 'instant'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Instant Auto-Dispatch Flow (Plumbing / Cleaning)</span>
          </button>
        </div>
      </div>

      {/* Interactive Flow Stepper & State Machine Runner */}
      <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
              Interactive State Machine Simulation
            </span>
            <h3 className="text-lg font-bold text-white mt-0.5">
              Current Phase: {activeSteps[currentIndex].title}
            </h3>
            <span className="text-xs text-slate-400">
              State: <code className="text-amber-400 bg-slate-950 px-2 py-0.5 rounded font-mono">{activeSteps[currentIndex].state}</code>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetFlow}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Flow</span>
            </button>

            <button
              onClick={handleNextStep}
              disabled={currentIndex >= activeSteps.length - 1}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer ${
                currentIndex >= activeSteps.length - 1
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
              }`}
            >
              <span>Advance Next Transition</span>
              <Play className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>
        </div>

        {/* Horizontal Progress Bar */}
        <div className="relative">
          <div className="overflow-hidden h-2 bg-slate-800 rounded-full">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-500 rounded-full"
              style={{
                width: `${((currentIndex + 1) / activeSteps.length) * 100}%`,
              }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 mt-2 font-mono">
            <span>Step {currentIndex + 1} of {activeSteps.length}</span>
            <span>Progress: {Math.round(((currentIndex + 1) / activeSteps.length) * 100)}%</span>
          </div>
        </div>

        {/* Active Step Detailed Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-950/70 p-5 rounded-xl border border-slate-800">
          <div className="space-y-2 md:col-span-2">
            <div className="flex items-center gap-2">
              <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 px-2 py-0.5 rounded font-bold">
                Primary Actor: {activeSteps[currentIndex].actor}
              </span>
              <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                SLA: {activeSteps[currentIndex].sla}
              </span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed mt-2">
              {activeSteps[currentIndex].description}
            </p>

            <div className="pt-3 border-t border-slate-800 flex flex-wrap gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-purple-400" />
                <span>DB Mutation: <strong className="text-slate-200">{activeSteps[currentIndex].dbTable}</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-amber-400" />
                <span>Kafka Event: <strong className="text-slate-200 font-mono">{activeSteps[currentIndex].eventTopic}</strong></span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col justify-between text-xs space-y-2">
            <span className="font-bold text-white text-[11px] uppercase tracking-wider text-slate-400">
              Exception & Fallback Handling
            </span>
            <p className="text-[11px] text-slate-300 leading-normal">
              {activeFlowType === 'instant'
                ? 'If partner fails to accept within 30 seconds, Redlock expires and job cascades to next nearest candidate (distance +2km).'
                : 'If customer flags quality defects during photo inspection, Escrow freeze triggers automatically and Ops dispute agent mediates within 2 hours.'}
            </p>
            <div className="text-[10px] text-amber-400 flex items-center gap-1 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Zero Money Lost Guarantee</span>
            </div>
          </div>
        </div>

        {/* Step-by-Step Overview Grid */}
        <div className="space-y-2 pt-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Lifecycle Sequence Breakdown
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {activeSteps.map((step, idx) => {
              const isPast = idx < currentIndex;
              const isCurrent = idx === currentIndex;
              return (
                <div
                  key={idx}
                  onClick={() =>
                    activeFlowType === 'instant'
                      ? setCurrentInstantIndex(idx)
                      : setCurrentMilestoneIndex(idx)
                  }
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                    isCurrent
                      ? 'bg-amber-500/15 border-amber-500 shadow-md text-white'
                      : isPast
                      ? 'bg-slate-900/60 border-emerald-500/30 text-slate-300'
                      : 'bg-slate-900/40 border-slate-800 text-slate-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{step.title}</span>
                    {isPast ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : isCurrent ? (
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                    ) : null}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 truncate">{step.actor}</div>
                  <div className="text-[9px] font-mono text-slate-500 mt-1 truncate">{step.eventTopic}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
