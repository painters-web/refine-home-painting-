import React, { useState } from 'react';
import {
  MICROSERVICES,
  THIRD_PARTY_INTEGRATIONS,
  ARCHITECTURE_OVERVIEW,
  MicroserviceDef,
} from '../data/architectureData';
import {
  Layers,
  Server,
  Database,
  Radio,
  Lock,
  ArrowRight,
  Shield,
  Cpu,
  Smartphone,
  Monitor,
  CheckCircle2,
  Share2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const [selectedService, setSelectedService] = useState<MicroserviceDef>(MICROSERVICES[3]); // Dispatch default
  const [expandedSection, setExpandedSection] = useState<'topology' | 'stack' | 'security' | 'integrations'>('topology');

  return (
    <div className="space-y-8 pb-12">
      {/* Executive Summary Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
              <Layers className="w-3.5 h-3.5" />
              Production Solutions Architecture Spec
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white">
              Refine Homes Multi-Vertical Core Platform Architecture
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              An enterprise-grade, event-driven distributed system designed to power multi-vertical on-demand home care. Built for sub-second partner dispatching, 3-stage milestone escrow protection, dynamic localized surge pricing, and privacy-first number masking.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 gap-3 w-full lg:w-auto shrink-0">
            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block">Dispatch SLA</span>
              <span className="text-lg font-bold text-amber-400">&lt; 800ms</span>
              <span className="text-[10px] text-slate-500 block">Redis GEO + H3</span>
            </div>
            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block">Escrow Security</span>
              <span className="text-lg font-bold text-emerald-400">3-Stage</span>
              <span className="text-[10px] text-slate-500 block">40% / 40% / 20%</span>
            </div>
            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block">Availability</span>
              <span className="text-lg font-bold text-blue-400">99.95%</span>
              <span className="text-[10px] text-slate-500 block">Multi-AZ K8s</span>
            </div>
            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block">Take Rate</span>
              <span className="text-lg font-bold text-purple-400">18%</span>
              <span className="text-[10px] text-slate-500 block">Automated Split</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Pills for Deep Dive */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setExpandedSection('topology')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            expandedSection === 'topology'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
          }`}
        >
          1. System Topology & C4 Container Diagram
        </button>
        <button
          onClick={() => setExpandedSection('stack')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            expandedSection === 'stack'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
          }`}
        >
          2. Tech Stack Rationale Matrix
        </button>
        <button
          onClick={() => setExpandedSection('integrations')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            expandedSection === 'integrations'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
          }`}
        >
          3. Third-Party Integrations
        </button>
        <button
          onClick={() => setExpandedSection('security')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            expandedSection === 'security'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
          }`}
        >
          4. Security & Privacy Architecture
        </button>
      </div>

      {/* 1. TOPOLOGY & C4 CONTAINERS */}
      {expandedSection === 'topology' && (
        <div className="space-y-6">
          {/* C4 Visual Architecture Map */}
          <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                C4 Container Topology (Clients &rarr; Edge Gateway &rarr; Microservices &rarr; Storage)
              </h3>
              <span className="text-xs text-slate-400">Click any microservice below to inspect</span>
            </div>

            {/* Architecture Flow Columns */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Column 1: Client Applications */}
              <div className="space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-amber-400/90 px-1 flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" />
                  Client Apps (Cross-Platform)
                </div>

                <div className="bg-slate-800/70 p-3.5 rounded-xl border border-slate-700/60 hover:border-amber-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Customer App</span>
                    <span className="text-[10px] bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded">Flutter</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Category grid, dynamic intake forms, live map tracking, Razorpay checkout, 3-stage quote approvals.
                  </p>
                </div>

                <div className="bg-slate-800/70 p-3.5 rounded-xl border border-slate-700/60 hover:border-amber-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Partner Pro App</span>
                    <span className="text-[10px] bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded">Flutter</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    30s job radar auction, digital laser measurement tool, milestone photo proof, daily wallet payouts.
                  </p>
                </div>

                <div className="bg-slate-800/70 p-3.5 rounded-xl border border-slate-700/60 hover:border-amber-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Admin & Ops Dashboard</span>
                    <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded">React / Next.js</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Geofence polygons, dynamic surge overrides, partner KYC validation desk, dispute arbitration desk.
                  </p>
                </div>
              </div>

              {/* Column 2: Edge & Ingress */}
              <div className="space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-indigo-400/90 px-1 flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5" />
                  Edge & API Gateway
                </div>

                <div className="bg-indigo-950/40 p-4 rounded-xl border border-indigo-800/40 h-[calc(100%-2rem)] flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold text-indigo-200">Kong API Gateway & Envoy</span>
                    <p className="text-[11px] text-slate-300 mt-2">
                      Handles all REST & WebSocket traffic ingress, JWT validation, Redis token bucket rate limiting, and mTLS internal routing.
                    </p>

                    <div className="mt-4 space-y-2">
                      <div className="text-[10px] bg-slate-900/90 p-2 rounded text-slate-300 border border-slate-800">
                        <span className="text-amber-400 font-mono">/api/v1/auth</span> &rarr; Auth Service
                      </div>
                      <div className="text-[10px] bg-slate-900/90 p-2 rounded text-slate-300 border border-slate-800">
                        <span className="text-amber-400 font-mono">/api/v1/dispatch</span> &rarr; Dispatch Engine
                      </div>
                      <div className="text-[10px] bg-slate-900/90 p-2 rounded text-slate-300 border border-slate-800">
                        <span className="text-amber-400 font-mono">/api/v1/bookings</span> &rarr; State Machine
                      </div>
                      <div className="text-[10px] bg-slate-900/90 p-2 rounded text-slate-300 border border-slate-800">
                        <span className="text-amber-400 font-mono">/socket.io/</span> &rarr; Real-Time Comms
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-indigo-900/50 text-[10px] text-indigo-300">
                    Cloudflare WAF + DDoS Mitigation
                  </div>
                </div>
              </div>

              {/* Column 3: Core Microservices */}
              <div className="space-y-2">
                <div className="text-xs font-bold uppercase tracking-wider text-emerald-400/90 px-1 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5" />
                  Core Microservices
                </div>

                {MICROSERVICES.slice(1).map((svc) => {
                  const isSelected = selectedService.id === svc.id;
                  return (
                    <button
                      key={svc.id}
                      onClick={() => setSelectedService(svc)}
                      className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-500/60 shadow-md text-white'
                          : 'bg-slate-800/60 border-slate-700/50 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="font-semibold text-white flex items-center justify-between">
                        <span>{svc.name}</span>
                        <ArrowRight className="w-3 h-3 text-slate-500" />
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5 truncate">{svc.tech}</div>
                    </button>
                  );
                })}
              </div>

              {/* Column 4: Storage, Events & 3P */}
              <div className="space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-purple-400/90 px-1 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5" />
                  Persistence & Events
                </div>

                <div className="bg-slate-800/70 p-3 rounded-xl border border-slate-700/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">PostgreSQL 16 + PostGIS</span>
                    <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded">Primary ACID</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Relational storage with spatial indexing (`ST_DWithin`, `ST_Contains`) for city geofences.
                  </p>
                </div>

                <div className="bg-slate-800/70 p-3 rounded-xl border border-slate-700/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Redis Cluster 7</span>
                    <span className="text-[10px] bg-red-500/20 text-red-300 px-1.5 py-0.5 rounded">GEO + Redlock</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Sub-millisecond partner coordinate streaming, job claim locks, and JWT session cache.
                  </p>
                </div>

                <div className="bg-slate-800/70 p-3 rounded-xl border border-slate-700/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Apache Kafka / RabbitMQ</span>
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded">Event Bus</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Event topics: `booking.requested`, `partner.assigned`, `milestone.verified`, `payout.initiated`.
                  </p>
                </div>

                <div className="bg-slate-800/70 p-3 rounded-xl border border-slate-700/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">AWS S3 + CloudFront</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded">Media Bucket</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Pre-signed upload for KYC Aadhaar docs, inspection floorplans, and milestone completion photos.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Microservice Inspector Drawer */}
          <div className="bg-slate-900 rounded-2xl p-6 border border-amber-500/40 shadow-xl">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                  Microservice Deep Dive
                </span>
                <h3 className="text-xl font-bold text-white">{selectedService.name}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{selectedService.tech}</p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs bg-slate-800 px-3 py-1 rounded-lg text-slate-300 border border-slate-700">
                  Database: <strong className="text-amber-400">{selectedService.database}</strong>
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Primary Architectural Role
                </h4>
                <p className="text-sm text-slate-200 leading-relaxed bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                  {selectedService.role}
                </p>

                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mt-4 mb-2">
                  Dependencies & Event Streams
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedService.dependencies.map((dep, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg text-xs bg-indigo-950/50 text-indigo-300 border border-indigo-800/60 font-mono"
                    >
                      {dep}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Core Responsibilities & Logic
                </h4>
                <div className="space-y-2">
                  {selectedService.responsibilities.map((resp, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{resp}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. TECH STACK RATIONALE MATRIX */}
      {expandedSection === 'stack' && (
        <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Cpu className="w-5 h-5 text-amber-400" />
              Technical Stack Selection & Architectural Rationale
            </h3>
            <span className="text-xs text-slate-400">Chosen for high concurrency and scale</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-3 px-4 font-semibold">Layer</th>
                  <th className="py-3 px-4 font-semibold">Chosen Technology</th>
                  <th className="py-3 px-4 font-semibold">Alternative Evaluated</th>
                  <th className="py-3 px-4 font-semibold">Why Refine Homes Chose This</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Mobile Frontend</td>
                  <td className="py-3.5 px-4 text-sky-400 font-semibold">Flutter (Dart)</td>
                  <td className="py-3.5 px-4 text-slate-400">React Native</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    Single unified codebase with guaranteed 60fps canvas rendering for complex painting measurement sheets, offline SQLite caching, and native GPS tracking hooks.
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Backend Services</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-semibold">Node.js (NestJS) + Go</td>
                  <td className="py-3.5 px-4 text-slate-400">Python Django / Ruby</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    NestJS provides strict TypeScript modularity and dependency injection for booking state machines; Go microservice handles the high-throughput geohash proximity dispatch engine.
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Primary Database</td>
                  <td className="py-3.5 px-4 text-indigo-400 font-semibold">PostgreSQL 16 + PostGIS</td>
                  <td className="py-3.5 px-4 text-slate-400">MongoDB</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    Strict ACID compliance is required for financial escrow ledgers and multi-milestone payouts. PostGIS enables polygon boundary checks for dynamic geofences and surge zones.
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Cache & Geolocation</td>
                  <td className="py-3.5 px-4 text-red-400 font-semibold">Redis Cluster 7 (GEO + Redlock)</td>
                  <td className="py-3.5 px-4 text-slate-400">Memcached / Elasticsearch</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    Native `GEOADD` and `GEORADIUS` calculate partner distances within 5 milliseconds. Redlock distributed locks prevent two partners from accepting the same dispatch assignment.
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Event Streaming</td>
                  <td className="py-3.5 px-4 text-amber-400 font-semibold">Apache Kafka / RabbitMQ</td>
                  <td className="py-3.5 px-4 text-slate-400">Synchronous REST calls</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    Decouples booking order creation from push notification dispatch, payment webhooks, invoice generation, and audit logging. Guarantees zero dropped events during flash demand spikes.
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Payment & Escrow</td>
                  <td className="py-3.5 px-4 text-purple-400 font-semibold">Razorpay Route / Stripe Connect</td>
                  <td className="py-3.5 px-4 text-slate-400">Manual Bank NEFT</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    Native support for split payments, automated milestone escrow retention, platform take-rate deduction (18%), and automated KYC beneficiary payouts.
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-bold text-white">Telephony Masking</td>
                  <td className="py-3.5 px-4 text-pink-400 font-semibold">Twilio / Exotel Voice Proxy</td>
                  <td className="py-3.5 px-4 text-slate-400">Direct GSM Calling</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    Protects customer privacy by bridging calls through temporary virtual numbers. Records conversations for dispute resolution and prevents platform disintermediation (cash leakage).
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. THIRD-PARTY INTEGRATIONS */}
      {expandedSection === 'integrations' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {THIRD_PARTY_INTEGRATIONS.map((integ, index) => (
            <div
              key={index}
              className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                    {integ.category}
                  </span>
                  <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">
                    Production API
                  </span>
                </div>
                <h4 className="text-base font-bold text-white mt-1.5">{integ.vendor}</h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">{integ.purpose}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>
                  Security & Compliance: <strong className="text-slate-200">{integ.security}</strong>
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 4. SECURITY & PRIVACY */}
      {expandedSection === 'security' && (
        <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-white">
              Enterprise Trust, Privacy Masking & KYC Compliance Blueprint
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <Lock className="w-4 h-4" />
                Number Masking & Anti-Leakage
              </div>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Customers and partners never see each other's private mobile numbers. When "Call Partner" is clicked, Twilio/Exotel routes through a temporary virtual bridge (DID). In-app chat runs regex filters to automatically mask phone numbers and personal UPI handles, preventing off-platform disintermediation.
              </p>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2 text-blue-400 font-bold text-sm">
                <Shield className="w-4 h-4" />
                Partner KYC Verification Pipeline
              </div>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Partners must complete a 4-step digital onboarding: Government ID OCR (Aadhaar/PAN via Digilocker API), Police Background Clearance, Skill Trade Certification, and Bank Account Penny-Drop validation. Only verified partners with active background checks are unlocked on the dispatch radar.
              </p>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2 text-purple-400 font-bold text-sm">
                <Database className="w-4 h-4" />
                Financial Escrow & Double-Entry Ledger
              </div>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                All customer payments are captured into an Escrow Holding Account. For milestone painting jobs, funds are locked in 3 tranches (40% Material, 40% Base, 20% Signoff). Every transaction records debit/credit entries in immutable PostgreSQL ledger tables, preventing any unbacked payouts.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
