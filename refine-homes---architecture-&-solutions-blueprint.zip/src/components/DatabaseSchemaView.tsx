import React, { useState } from 'react';
import {
  DATABASE_SCHEMA_TABLES,
  POSTGRESQL_DDL_SCRIPT,
  SchemaTableDef,
} from '../data/architectureData';
import {
  Database,
  Table,
  Key,
  Copy,
  Check,
  Code,
  ArrowRight,
  ShieldCheck,
  Download,
  Search,
} from 'lucide-react';

export const DatabaseSchemaView: React.FC = () => {
  const [selectedTable, setSelectedTable] = useState<SchemaTableDef>(DATABASE_SCHEMA_TABLES[4]); // Bookings default
  const [viewMode, setViewMode] = useState<'visual' | 'ddl'>('visual');
  const [copied, setCopied] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');

  const handleCopyDDL = () => {
    navigator.clipboard.writeText(POSTGRESQL_DDL_SCRIPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadDDL = () => {
    const blob = new Blob([POSTGRESQL_DDL_SCRIPT], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'refine_homes_schema.sql';
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredTables = DATABASE_SCHEMA_TABLES.filter((t) =>
    t.name.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Relational Database Architecture & DDL Studio</h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
              PostgreSQL 16 + PostGIS
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-3xl">
            Normalized schemas supporting ACID financial escrow ledgers, geospatial PostGIS point/polygon indexing, 3-stage milestone release schedules, and partner wallet balances.
          </p>
        </div>

        {/* View Switcher & Copy Actions */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center">
            <button
              onClick={() => setViewMode('visual')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                viewMode === 'visual'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>ER Inspector</span>
            </button>
            <button
              onClick={() => setViewMode('ddl')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                viewMode === 'ddl'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Full PostgreSQL DDL</span>
            </button>
          </div>

          <button
            onClick={handleCopyDDL}
            className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied SQL!' : 'Copy DDL'}</span>
          </button>

          <button
            onClick={handleDownloadDDL}
            title="Download SQL File"
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {viewMode === 'visual' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Tables List Sidebar */}
          <div className="lg:col-span-4 bg-slate-900 rounded-2xl p-4 border border-slate-800 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Core Relational Entities ({DATABASE_SCHEMA_TABLES.length})
              </span>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search tables..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1.5 max-h-[620px] overflow-y-auto pr-1">
              {filteredTables.map((tbl) => {
                const isSelected = selectedTable.name === tbl.name;
                return (
                  <button
                    key={tbl.name}
                    onClick={() => setSelectedTable(tbl)}
                    className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-500 text-white font-bold shadow-md'
                        : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/80 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-semibold">{tbl.name}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded text-slate-400">
                        {tbl.columns.length} cols
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 truncate">{tbl.description}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Table Inspector Detailed View */}
          <div className="lg:col-span-8 bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                  Table Schema Definition
                </span>
                <h3 className="text-xl font-bold font-mono text-white mt-0.5">
                  {selectedTable.name}
                </h3>
                <p className="text-xs text-slate-400 mt-1">{selectedTable.description}</p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs bg-slate-800 px-2.5 py-1 rounded text-slate-300 border border-slate-700">
                  {selectedTable.columns.length} Attributes
                </span>
                <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 px-2.5 py-1 rounded font-bold">
                  {selectedTable.foreignKeys.length} Foreign Keys
                </span>
              </div>
            </div>

            {/* Columns Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3 font-semibold">Column Name</th>
                    <th className="py-2.5 px-3 font-semibold">Data Type</th>
                    <th className="py-2.5 px-3 font-semibold">Constraints</th>
                    <th className="py-2.5 px-3 font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {selectedTable.columns.map((col, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-mono font-bold text-white flex items-center gap-1.5">
                        {col.constraints?.includes('PRIMARY KEY') ? (
                          <Key className="w-3.5 h-3.5 text-amber-400" />
                        ) : col.name.endsWith('_id') ? (
                          <ArrowRight className="w-3 h-3 text-indigo-400" />
                        ) : null}
                        <span>{col.name}</span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-sky-400">{col.type}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px]">
                        {col.constraints || '-'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 text-xs">{col.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Foreign Keys & Indexes Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 block">
                  Foreign Key Relationships
                </span>
                {selectedTable.foreignKeys.length > 0 ? (
                  <div className="space-y-1.5">
                    {selectedTable.foreignKeys.map((fk, idx) => (
                      <div key={idx} className="text-xs bg-slate-900 p-2 rounded border border-slate-800 font-mono text-slate-300 flex items-center justify-between">
                        <span className="text-amber-400">{fk.column}</span>
                        <span className="text-slate-500">&rarr;</span>
                        <span className="text-indigo-300">
                          {fk.referencesTable}.{fk.referencesColumn}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">No foreign keys (Root entity table)</p>
                )}
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block">
                  Performance & Spatial Indexes
                </span>
                {selectedTable.indexes.length > 0 ? (
                  <div className="space-y-1.5">
                    {selectedTable.indexes.map((idxCode, idx) => (
                      <div key={idx} className="text-[11px] bg-slate-900 p-2 rounded border border-slate-800 font-mono text-emerald-300">
                        {idxCode}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">Default primary key index applied</p>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* DDL Code View */
        <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-amber-400 font-bold uppercase">Ready for Migration (Flyway / Drizzle / Prisma)</span>
              <h3 className="text-base font-bold text-white mt-0.5">PostgreSQL 16 Script with Spatial PostGIS</h3>
            </div>
            <button
              onClick={handleCopyDDL}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy All SQL'}</span>
            </button>
          </div>

          <pre className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 overflow-x-auto max-h-[600px] leading-relaxed">
            {POSTGRESQL_DDL_SCRIPT}
          </pre>
        </div>
      )}
    </div>
  );
};
