/**
 * Refine Homes - System Architecture, Database Schemas, and Technical Blueprint Data
 */

export interface MicroserviceDef {
  id: string;
  name: string;
  tech: string;
  role: string;
  responsibilities: string[];
  dependencies: string[];
  database: string;
}

export interface SchemaTableDef {
  name: string;
  description: string;
  columns: Array<{
    name: string;
    type: string;
    constraints?: string;
    description: string;
  }>;
  indexes: string[];
  foreignKeys: Array<{
    column: string;
    referencesTable: string;
    referencesColumn: string;
    onDelete?: string;
  }>;
}

export const ARCHITECTURE_OVERVIEW = {
  brand: 'Refine Homes',
  mission: 'Next-generation on-demand home services infrastructure delivering transparent, milestone-tracked, and quality-guaranteed home care across painting, quick tasks, deep cleaning, and appliance repair.',
  scaleTargets: {
    mvpPilot: '1 Metro City (Bengaluru/Mumbai), 500 Verified Partners, 5,000 Monthly Bookings',
    targetP95Latency: '< 180ms for API, < 800ms for Real-Time Dispatch Match',
    availabilitySla: '99.95% uptime',
    escrowSecurity: '100% financial reconciliation with automated double-entry ledger',
  },
};

export const MICROSERVICES: MicroserviceDef[] = [
  {
    id: 'api-gateway',
    name: 'API Gateway & Edge Router',
    tech: 'Kong / Envoy Gateway (Go/Lua)',
    role: 'Central traffic ingress, rate limiting, SSL termination, and JWT claim injection.',
    responsibilities: [
      'Token verification & claim enrichment via Redis session store',
      'Rate limiting by IP and User-ID (Token Bucket algorithm)',
      'Route proxying with latency tracking and circuit breaker fallback',
      'CORS handling and Webhook signature validation for payment providers',
    ],
    dependencies: ['Redis Cluster', 'Auth Service'],
    database: 'Redis (Ephemeral Cache & Rate Limits)',
  },
  {
    id: 'auth-service',
    name: 'Auth & Identity Service',
    tech: 'Node.js (NestJS) + TypeScript',
    role: 'User & Partner identity lifecycle, phone OTP, role-based access control (RBAC).',
    responsibilities: [
      'Phone OTP authentication via Twilio / Exotel gateway with anti-abuse velocity checks',
      'Dual JWT generation (Access Token 15m, Refresh Token 30d with rotation in Redis)',
      'RBAC roles: CUSTOMER, PARTNER, INSPECTOR, OPS_ADMIN, SUPER_ADMIN',
      'Partner KYC submission and background check document staging',
    ],
    dependencies: ['PostgreSQL (Users, Partners)', 'Redis', 'Twilio/Exotel'],
    database: 'PostgreSQL & Redis',
  },
  {
    id: 'catalog-service',
    name: 'Service Catalog & Pricing Service',
    tech: 'Node.js (NestJS) / TypeScript',
    role: 'Catalog hierarchy, dynamic form schemas per vertical, and dynamic surge pricing.',
    responsibilities: [
      'Service vertical taxonomy: Painting, Quick Tasks, Cleaning, Appliance Repair',
      'Dynamic field schema definitions for frontend form rendering (e.g., room counts, square footage)',
      'Dynamic pricing matrix evaluation (base rates, spare parts catalog, material tiers)',
      'Surge pricing computation engine based on localized geofence demand/supply ratio',
    ],
    dependencies: ['PostgreSQL (Catalog)', 'Redis (Surge Multiplier Cache)'],
    database: 'PostgreSQL',
  },
  {
    id: 'dispatch-service',
    name: 'Dispatch & Geolocation Engine',
    tech: 'Go (Golang) / NestJS Microservice',
    role: 'High-throughput partner proximity search, geohashing, and 30-sec dispatch radar.',
    responsibilities: [
      'High-frequency partner heartbeat updates stored in Redis GEO (H3 spatial index resolution 8)',
      'Instant booking matchmaker: finds top 5 verified, available partners within 8km radius',
      'Distributed Redis Lock (Redlock) to prevent duplicate job assignment races',
      'Cascading dispatch queue: 30s accept timer -> timeout -> fallback to next nearest candidate',
    ],
    dependencies: ['Redis Cluster GEO', 'Kafka Topic: booking.dispatch_requested', 'PostgreSQL'],
    database: 'Redis GEO & PostGIS',
  },
  {
    id: 'booking-service',
    name: 'Booking & Milestone State Machine',
    tech: 'Node.js (NestJS) with Clean Architecture',
    role: 'Orchestrates the entire booking lifecycle for Instant and Inspection/Milestone workflows.',
    responsibilities: [
      'Instant booking state machine: REQUESTED -> MATCHING -> ASSIGNED -> EN_ROUTE -> IN_PROGRESS -> COMPLETED',
      'Painting milestone state machine: LEAD -> INSPECTION -> QUOTATION -> STAGE1 -> STAGE2 -> FINAL_QA',
      'Event publishing to Apache Kafka / RabbitMQ topics',
      'Digital inspection report generation with square-footage laser data and photo attachments',
    ],
    dependencies: ['PostgreSQL', 'Kafka / RabbitMQ', 'AWS S3', 'Notification Service'],
    database: 'PostgreSQL',
  },
  {
    id: 'escrow-payment-service',
    name: 'Payment & Escrow Ledger Service',
    tech: 'Go (Golang) or Node.js / TypeScript',
    role: 'Split payments, milestone escrow holding, wallet balance ledgers, and partner payouts.',
    responsibilities: [
      'Stripe Connect / Razorpay Route integration for split transfers & escrow holds',
      'Milestone-based release triggers (Stage 1: 40%, Stage 2: 40%, Stage 3: 20%)',
      'Immutable double-entry ledger for Partner Wallets and platform commission deductions (18%)',
      'Automated daily/weekly payout batching (IMPS / ACH) with fraud threshold checks',
    ],
    dependencies: ['Razorpay / Stripe API', 'PostgreSQL (Payments, Wallets, Ledgers)'],
    database: 'PostgreSQL (ACID Transactions)',
  },
  {
    id: 'realtime-comm-service',
    name: 'Real-Time Tracking & Masked Comms',
    tech: 'Node.js (Socket.io) + Redis Adapter',
    role: 'Live partner GPS tracking on map, in-app messaging, and phone number masking.',
    responsibilities: [
      'WebSocket rooms per active booking (`room:booking:{id}`)',
      '60Hz partner location streaming during EN_ROUTE phase with route polyline interpolation',
      'In-app ephemeral chat with automated chat sanitization (blocks phone numbers in chat)',
      'Twilio / Exotel Voice Proxy (virtual bridge numbers) to protect customer & partner privacy',
    ],
    dependencies: ['Redis Pub/Sub', 'Twilio / Exotel Voice Proxy', 'Google Maps Distance Matrix API'],
    database: 'Redis Pub/Sub',
  },
];

export const THIRD_PARTY_INTEGRATIONS = [
  {
    category: 'Payments & Escrow',
    vendor: 'Razorpay Route / Stripe Connect',
    purpose: 'Customer payment processing, milestone escrow holding account, automated split payout to Partner bank account, and refund handling.',
    security: 'PCI-DSS Level 1 compliant, webhook signature validation using HMAC-SHA256.',
  },
  {
    category: 'Maps & Spatial Intelligence',
    vendor: 'Google Maps Platform (Places, Geocoding, Distance Matrix, Directions API)',
    purpose: 'Precise customer address autocomplete, geocoding to Lat/Lon coordinates, partner ETA calculations, and route polyline visualization.',
    security: 'API keys restricted by HTTP referrer / IP whitelist, server-side caching of route matrices in Redis.',
  },
  {
    category: 'Media & Document Storage',
    vendor: 'AWS S3 + CloudFront CDN',
    purpose: 'Secure storage of partner KYC documents (Aadhaar, driving license, trade certificates), job site before/after photos, and inspection blueprints.',
    security: 'Private buckets, pre-signed temporary upload/download URLs (TTL 15 mins), Server-Side Encryption (SSE-S3).',
  },
  {
    category: 'Telephony & Privacy Masking',
    vendor: 'Twilio / Exotel Voice API',
    purpose: 'Dynamic number masking (virtual relay bridge) so customers and partners can call each other without seeing real private phone numbers.',
    security: 'Calls recorded for dispute audit and quality checks; relay terminates immediately upon job completion.',
  },
  {
    category: 'Push & SMS Notifications',
    vendor: 'Firebase Cloud Messaging (FCM) + SMS Gateway',
    purpose: 'Instant job dispatch alerts with sound alarm, OTP verification codes, milestone signoff notifications, and customer status updates.',
    security: 'High-priority FCM channels with background audio triggers for partner acceptance alerts.',
  },
];

export const DATABASE_SCHEMA_TABLES: SchemaTableDef[] = [
  {
    name: 'users',
    description: 'Core customer profile, authentication credentials, and address books.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Unique user identifier' },
      { name: 'phone', type: 'VARCHAR(15)', constraints: 'UNIQUE NOT NULL', description: 'E.164 normalized mobile number' },
      { name: 'full_name', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Customer legal name' },
      { name: 'email', type: 'VARCHAR(255)', constraints: 'UNIQUE', description: 'Email address for invoices' },
      { name: 'role', type: 'VARCHAR(20)', constraints: 'NOT NULL DEFAULT \'CUSTOMER\'', description: 'CUSTOMER, ADMIN, OPS' },
      { name: 'is_active', type: 'BOOLEAN', constraints: 'DEFAULT true', description: 'Account status flag' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT NOW()', description: 'Record creation timestamp' },
      { name: 'updated_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT NOW()', description: 'Last update timestamp' },
    ],
    indexes: ['CREATE UNIQUE INDEX idx_users_phone ON users(phone);'],
    foreignKeys: [],
  },
  {
    name: 'partners',
    description: 'Service professionals, KYC verification state, skill categories, and live coordinates.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Partner unique identifier' },
      { name: 'phone', type: 'VARCHAR(15)', constraints: 'UNIQUE NOT NULL', description: 'Registered phone for app login' },
      { name: 'full_name', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Partner legal full name' },
      { name: 'category_id', type: 'UUID', constraints: 'NOT NULL', description: 'Primary service category reference' },
      { name: 'kyc_status', type: 'VARCHAR(20)', constraints: 'NOT NULL DEFAULT \'PENDING\'', description: 'PENDING, VERIFIED, REJECTED, SUSPENDED' },
      { name: 'rating_avg', type: 'NUMERIC(3,2)', constraints: 'DEFAULT 5.00', description: 'Aggregated review rating score (0.00 to 5.00)' },
      { name: 'total_jobs_completed', type: 'INTEGER', constraints: 'DEFAULT 0', description: 'Total lifetime completed bookings' },
      { name: 'is_online', type: 'BOOLEAN', constraints: 'DEFAULT false', description: 'Availability toggle for dispatch radar' },
      { name: 'has_active_job', type: 'BOOLEAN', constraints: 'DEFAULT false', description: 'Lock indicator if currently serving a customer' },
      { name: 'current_lat', type: 'NUMERIC(10,7)', description: 'Last known GPS latitude' },
      { name: 'current_lon', type: 'NUMERIC(10,7)', description: 'Last known GPS longitude' },
      { name: 'bank_account_verified', type: 'BOOLEAN', constraints: 'DEFAULT false', description: 'Payout bank verification flag' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT NOW()', description: 'Registration timestamp' },
    ],
    indexes: [
      'CREATE INDEX idx_partners_category ON partners(category_id);',
      'CREATE INDEX idx_partners_online_kyc ON partners(is_online, kyc_status);',
    ],
    foreignKeys: [
      { column: 'category_id', referencesTable: 'service_categories', referencesColumn: 'id' },
    ],
  },
  {
    name: 'service_categories',
    description: 'Top-level business verticals (Painting, Quick Tasks, Cleaning, Appliance).',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Category identifier' },
      { name: 'slug', type: 'VARCHAR(50)', constraints: 'UNIQUE NOT NULL', description: 'painting, quick-tasks, cleaning, appliance-repair' },
      { name: 'name', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Display name' },
      { name: 'pricing_model', type: 'VARCHAR(30)', constraints: 'NOT NULL', description: 'MILESTONE_INSPECTION, HOURLY_FIXED, PACKAGE_FLAT, INSPECTION_PARTS' },
      { name: 'base_commission_rate', type: 'NUMERIC(4,2)', constraints: 'DEFAULT 0.18', description: 'Refine Homes platform fee percentage (18%)' },
      { name: 'is_active', type: 'BOOLEAN', constraints: 'DEFAULT true', description: 'Category enabled flag' },
    ],
    indexes: ['CREATE UNIQUE INDEX idx_categories_slug ON service_categories(slug);'],
    foreignKeys: [],
  },
  {
    name: 'services',
    description: 'Specific actionable services within each category (e.g. Full Home Painting, Drain Unclogging, 2BHK Deep Clean).',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Service identifier' },
      { name: 'category_id', type: 'UUID', constraints: 'NOT NULL', description: 'Parent category' },
      { name: 'title', type: 'VARCHAR(150)', constraints: 'NOT NULL', description: 'Service item title' },
      { name: 'base_price', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Starting or baseline price in INR' },
      { name: 'price_unit', type: 'VARCHAR(30)', constraints: 'NOT NULL', description: 'PER_SQFT, PER_HOUR, PER_JOB, INSPECTION_BASE' },
      { name: 'estimated_duration_mins', type: 'INTEGER', description: 'Expected completion window' },
      { name: 'dynamic_form_schema', type: 'JSONB', constraints: 'NOT NULL', description: 'JSON schema defining required customer inputs' },
    ],
    indexes: ['CREATE INDEX idx_services_category ON services(category_id);'],
    foreignKeys: [
      { column: 'category_id', referencesTable: 'service_categories', referencesColumn: 'id' },
    ],
  },
  {
    name: 'bookings',
    description: 'Primary customer orders, lifecycle statuses, scheduled slots, and assigned partner.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Booking order ID' },
      { name: 'booking_code', type: 'VARCHAR(20)', constraints: 'UNIQUE NOT NULL', description: 'Human-readable reference e.g. RFN-2026-9812' },
      { name: 'user_id', type: 'UUID', constraints: 'NOT NULL', description: 'Ordering customer' },
      { name: 'service_id', type: 'UUID', constraints: 'NOT NULL', description: 'Requested service catalog item' },
      { name: 'partner_id', type: 'UUID', description: 'Assigned service partner (null if searching)' },
      { name: 'status', type: 'VARCHAR(30)', constraints: 'NOT NULL', description: 'REQUESTED, MATCHING, ASSIGNED, EN_ROUTE, IN_PROGRESS, COMPLETED, CANCELLED' },
      { name: 'booking_type', type: 'VARCHAR(20)', constraints: 'NOT NULL', description: 'INSTANT or MILESTONE_INSPECTION' },
      { name: 'scheduled_date', type: 'DATE', constraints: 'NOT NULL', description: 'Requested booking date' },
      { name: 'scheduled_slot', type: 'VARCHAR(30)', constraints: 'NOT NULL', description: 'e.g. 10:00 AM - 12:00 PM' },
      { name: 'customer_address', type: 'TEXT', constraints: 'NOT NULL', description: 'Full site delivery address' },
      { name: 'site_lat', type: 'NUMERIC(10,7)', constraints: 'NOT NULL', description: 'Geo latitude for dispatching' },
      { name: 'site_lon', type: 'NUMERIC(10,7)', constraints: 'NOT NULL', description: 'Geo longitude for dispatching' },
      { name: 'total_amount', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Final or estimated price' },
      { name: 'otp_verification_code', type: 'VARCHAR(6)', description: 'Secure 4 or 6-digit start/completion OTP' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT NOW()', description: 'Booking created time' },
    ],
    indexes: [
      'CREATE INDEX idx_bookings_user ON bookings(user_id);',
      'CREATE INDEX idx_bookings_partner ON bookings(partner_id);',
      'CREATE INDEX idx_bookings_status ON bookings(status);',
      'CREATE INDEX idx_bookings_created ON bookings(created_at DESC);',
    ],
    foreignKeys: [
      { column: 'user_id', referencesTable: 'users', referencesColumn: 'id' },
      { column: 'service_id', referencesTable: 'services', referencesColumn: 'id' },
      { column: 'partner_id', referencesTable: 'partners', referencesColumn: 'id' },
    ],
  },
  {
    name: 'quotations',
    description: 'Digital inspection estimates created by partners on-site for Painting or Appliance Repair.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Quotation ID' },
      { name: 'booking_id', type: 'UUID', constraints: 'NOT NULL', description: 'Related inspection booking' },
      { name: 'partner_id', type: 'UUID', constraints: 'NOT NULL', description: 'Inspector / partner author' },
      { name: 'wall_area_sqft', type: 'INTEGER', description: 'Measured wall square footage' },
      { name: 'paint_tier', type: 'VARCHAR(30)', description: 'ECONOMY, PREMIUM, LUXURY' },
      { name: 'parts_items', type: 'JSONB', description: 'Array of spare parts with rates (for appliance)' },
      { name: 'base_cost', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Calculated work subtotal' },
      { name: 'gst_amount', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: '18% GST' },
      { name: 'grand_total', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Approved gross quote' },
      { name: 'customer_approved_at', type: 'TIMESTAMPTZ', description: 'Timestamp when customer signed off' },
      { name: 'status', type: 'VARCHAR(20)', constraints: 'DEFAULT \'DRAFT\'', description: 'DRAFT, SUBMITTED, APPROVED, REJECTED' },
    ],
    indexes: ['CREATE INDEX idx_quotations_booking ON quotations(booking_id);'],
    foreignKeys: [
      { column: 'booking_id', referencesTable: 'bookings', referencesColumn: 'id' },
      { column: 'partner_id', referencesTable: 'partners', referencesColumn: 'id' },
    ],
  },
  {
    name: 'milestones',
    description: '3-stage milestone release schedule and verification audit proof for long-duration jobs.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Milestone ID' },
      { name: 'booking_id', type: 'UUID', constraints: 'NOT NULL', description: 'Parent milestone booking' },
      { name: 'stage_number', type: 'SMALLINT', constraints: 'NOT NULL', description: '1, 2, or 3' },
      { name: 'title', type: 'VARCHAR(120)', constraints: 'NOT NULL', description: 'Stage title (e.g. Material Delivery)' },
      { name: 'amount', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'INR value held in escrow' },
      { name: 'percentage', type: 'INTEGER', constraints: 'NOT NULL', description: '40, 40, or 20' },
      { name: 'status', type: 'VARCHAR(30)', constraints: 'DEFAULT \'PENDING_LOCK\'', description: 'PENDING_LOCK, LOCKED_ESCROW, WORK_SUBMITTED, VERIFIED_RELEASED, DISPUTED' },
      { name: 'proof_images', type: 'JSONB', description: 'S3 URLs of completed stage photos' },
      { name: 'verified_by_user_at', type: 'TIMESTAMPTZ', description: 'Customer approval timestamp' },
    ],
    indexes: ['CREATE INDEX idx_milestones_booking ON milestones(booking_id);'],
    foreignKeys: [
      { column: 'booking_id', referencesTable: 'bookings', referencesColumn: 'id' },
    ],
  },
  {
    name: 'payments',
    description: 'Financial transactions, gateway IDs, payment mode, and escrow status.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Payment ID' },
      { name: 'booking_id', type: 'UUID', constraints: 'NOT NULL', description: 'Target booking' },
      { name: 'gateway_transaction_id', type: 'VARCHAR(100)', constraints: 'UNIQUE', description: 'Razorpay / Stripe charge identifier' },
      { name: 'amount', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Captured amount in INR' },
      { name: 'payment_method', type: 'VARCHAR(30)', constraints: 'NOT NULL', description: 'UPI, CREDIT_CARD, NET_BANKING, WALLET' },
      { name: 'escrow_status', type: 'VARCHAR(30)', constraints: 'NOT NULL', description: 'HELD_IN_ESCROW, PARTIALLY_RELEASED, FULLY_RELEASED, REFUNDED' },
      { name: 'platform_commission', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Refine Homes revenue share' },
      { name: 'partner_net_share', type: 'NUMERIC(10,2)', constraints: 'NOT NULL', description: 'Payable to partner wallet' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT NOW()', description: 'Payment timestamp' },
    ],
    indexes: ['CREATE INDEX idx_payments_booking ON payments(booking_id);'],
    foreignKeys: [
      { column: 'booking_id', referencesTable: 'bookings', referencesColumn: 'id' },
    ],
  },
  {
    name: 'wallets',
    description: 'Partner virtual balance, escrow holds, and ledger transactions.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Wallet ID' },
      { name: 'partner_id', type: 'UUID', constraints: 'UNIQUE NOT NULL', description: 'Partner owner' },
      { name: 'available_balance', type: 'NUMERIC(10,2)', constraints: 'DEFAULT 0.00', description: 'Withdrawable funds' },
      { name: 'pending_escrow_balance', type: 'NUMERIC(10,2)', constraints: 'DEFAULT 0.00', description: 'Locked in ongoing jobs' },
      { name: 'lifetime_earnings', type: 'NUMERIC(12,2)', constraints: 'DEFAULT 0.00', description: 'Cumulative net earnings' },
      { name: 'last_payout_at', type: 'TIMESTAMPTZ', description: 'Last bank disbursement' },
    ],
    indexes: ['CREATE UNIQUE INDEX idx_wallets_partner ON wallets(partner_id);'],
    foreignKeys: [
      { column: 'partner_id', referencesTable: 'partners', referencesColumn: 'id' },
    ],
  },
  {
    name: 'reviews',
    description: 'Customer ratings, feedback tags, and partner performance metrics.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()', description: 'Review ID' },
      { name: 'booking_id', type: 'UUID', constraints: 'UNIQUE NOT NULL', description: '1 review per booking' },
      { name: 'user_id', type: 'UUID', constraints: 'NOT NULL', description: 'Reviewer' },
      { name: 'partner_id', type: 'UUID', constraints: 'NOT NULL', description: 'Rated partner' },
      { name: 'rating_score', type: 'SMALLINT', constraints: 'NOT NULL CHECK (rating_score BETWEEN 1 AND 5)', description: 'Star score 1-5' },
      { name: 'comment', type: 'TEXT', description: 'Customer qualitative feedback' },
      { name: 'aspect_tags', type: 'JSONB', description: 'Tags: Punctual, Clean Work, Expert, Courteous' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT NOW()', description: 'Review submission timestamp' },
    ],
    indexes: [
      'CREATE INDEX idx_reviews_partner ON reviews(partner_id);',
      'CREATE INDEX idx_reviews_rating ON reviews(rating_score);',
    ],
    foreignKeys: [
      { column: 'booking_id', referencesTable: 'bookings', referencesColumn: 'id' },
      { column: 'user_id', referencesTable: 'users', referencesColumn: 'id' },
      { column: 'partner_id', referencesTable: 'partners', referencesColumn: 'id' },
    ],
  },
];

export const POSTGRESQL_DDL_SCRIPT = `-- ====================================================================
-- Refine Homes: Production PostgreSQL Schema (DDL)
-- Includes PostGIS extensions, enum types, relational foreign keys,
-- and automated balance trigger functions.
-- ====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- 1. ENUMS
CREATE TYPE user_role AS ENUM ('CUSTOMER', 'PARTNER', 'INSPECTOR', 'OPS_ADMIN', 'SUPER_ADMIN');
CREATE TYPE kyc_status_enum AS ENUM ('PENDING', 'DOCUMENTS_SUBMITTED', 'VERIFIED', 'REJECTED', 'SUSPENDED');
CREATE TYPE pricing_model_enum AS ENUM ('MILESTONE_INSPECTION', 'HOURLY_FIXED', 'PACKAGE_FLAT', 'INSPECTION_PARTS');
CREATE TYPE booking_status_enum AS ENUM ('REQUESTED', 'MATCHING_RADAR', 'PARTNER_ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'WORK_STARTED', 'COMPLETED', 'CANCELLED', 'EXPIRED');
CREATE TYPE milestone_status_enum AS ENUM ('PENDING_LOCK', 'LOCKED_ESCROW', 'WORK_SUBMITTED', 'VERIFIED_RELEASED', 'DISPUTED');
CREATE TYPE escrow_status_enum AS ENUM ('HELD_IN_ESCROW', 'PARTIALLY_RELEASED', 'FULLY_RELEASED', 'REFUNDED');

-- 2. USERS TABLE
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone VARCHAR(15) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    role user_role NOT NULL DEFAULT 'CUSTOMER',
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_users_phone ON users(phone);

-- 3. SERVICE CATEGORIES
CREATE TABLE service_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    pricing_model pricing_model_enum NOT NULL,
    base_commission_rate NUMERIC(4,2) DEFAULT 0.18,
    icon_name VARCHAR(50),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. PARTNERS TABLE
CREATE TABLE partners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    phone VARCHAR(15) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    category_id UUID NOT NULL REFERENCES service_categories(id),
    kyc_status kyc_status_enum NOT NULL DEFAULT 'PENDING',
    kyc_documents JSONB DEFAULT '{}'::jsonb,
    rating_avg NUMERIC(3,2) DEFAULT 5.00,
    total_jobs_completed INTEGER DEFAULT 0,
    is_online BOOLEAN DEFAULT false,
    has_active_job BOOLEAN DEFAULT false,
    current_location GEOMETRY(Point, 4326),
    bank_account_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_partners_geom ON partners USING GIST(current_location);
CREATE INDEX idx_partners_dispatch ON partners(category_id, is_online, kyc_status) WHERE is_online = true AND kyc_status = 'VERIFIED';

-- 5. SERVICES TABLE
CREATE TABLE services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id UUID NOT NULL REFERENCES service_categories(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    base_price NUMERIC(10,2) NOT NULL,
    price_unit VARCHAR(30) NOT NULL, -- 'PER_SQFT', 'PER_HOUR', 'PER_JOB', 'INSPECTION_BASE'
    estimated_duration_mins INTEGER,
    dynamic_form_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. GEOFENCE ZONES & SURGE PRICING
CREATE TABLE geofence_zones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    city VARCHAR(50) NOT NULL,
    zone_name VARCHAR(100) NOT NULL,
    boundary GEOMETRY(Polygon, 4326) NOT NULL,
    surge_multiplier NUMERIC(3,2) DEFAULT 1.00 CHECK (surge_multiplier BETWEEN 1.00 AND 3.00),
    is_active BOOLEAN DEFAULT true
);
CREATE INDEX idx_geofence_boundary ON geofence_zones USING GIST(boundary);

-- 7. BOOKINGS TABLE
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_code VARCHAR(25) UNIQUE NOT NULL,
    user_id UUID NOT NULL REFERENCES users(id),
    service_id UUID NOT NULL REFERENCES services(id),
    partner_id UUID REFERENCES partners(id),
    status booking_status_enum NOT NULL DEFAULT 'REQUESTED',
    booking_type VARCHAR(20) NOT NULL, -- 'INSTANT' or 'MILESTONE_INSPECTION'
    scheduled_date DATE NOT NULL,
    scheduled_slot VARCHAR(40) NOT NULL,
    customer_address TEXT NOT NULL,
    site_location GEOMETRY(Point, 4326) NOT NULL,
    total_amount NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    surge_multiplier NUMERIC(3,2) DEFAULT 1.00,
    start_otp VARCHAR(6),
    completion_otp VARCHAR(6),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_partner ON bookings(partner_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_site_loc ON bookings USING GIST(site_location);

-- 8. QUOTATIONS (For Painting Inspections & Appliance Spare Parts)
CREATE TABLE quotations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    partner_id UUID NOT NULL REFERENCES partners(id),
    carpet_area_sqft INTEGER,
    wall_area_sqft INTEGER,
    paint_tier VARCHAR(30), -- 'ECONOMY', 'PREMIUM', 'LUXURY'
    parts_breakdown JSONB DEFAULT '[]'::jsonb,
    subtotal NUMERIC(10,2) NOT NULL,
    gst_amount NUMERIC(10,2) NOT NULL,
    grand_total NUMERIC(10,2) NOT NULL,
    digital_signature_url TEXT,
    customer_approved_at TIMESTAMPTZ,
    status VARCHAR(20) DEFAULT 'DRAFT',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. MILESTONES (3-Stage Escrow Protection)
CREATE TABLE milestones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    stage_number SMALLINT NOT NULL CHECK (stage_number IN (1, 2, 3)),
    title VARCHAR(120) NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    percentage INTEGER NOT NULL CHECK (percentage IN (40, 20)),
    status milestone_status_enum NOT NULL DEFAULT 'PENDING_LOCK',
    proof_images JSONB DEFAULT '[]'::jsonb,
    work_notes TEXT,
    verified_by_user_at TIMESTAMPTZ,
    escrow_released_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_milestones_booking ON milestones(booking_id, stage_number);

-- 10. PAYMENTS TABLE
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id),
    milestone_id UUID REFERENCES milestones(id),
    gateway_transaction_id VARCHAR(100) UNIQUE,
    amount NUMERIC(10,2) NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    escrow_status escrow_status_enum NOT NULL DEFAULT 'HELD_IN_ESCROW',
    platform_commission NUMERIC(10,2) NOT NULL,
    partner_net_share NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. PARTNER WALLETS & LEDGER
CREATE TABLE wallets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    partner_id UUID UNIQUE NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    available_balance NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    pending_escrow_balance NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    lifetime_earnings NUMERIC(12,2) NOT NULL DEFAULT 0.00,
    last_payout_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE wallet_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_id UUID NOT NULL REFERENCES wallets(id),
    booking_id UUID REFERENCES bookings(id),
    type VARCHAR(30) NOT NULL, -- 'ESCROW_CREDIT', 'ESCROW_RELEASE', 'PAYOUT_TRANSFER', 'PENALTY'
    amount NUMERIC(10,2) NOT NULL,
    balance_after NUMERIC(10,2) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. REVIEWS & QUALITY RATINGS
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
    user_id UUID NOT NULL REFERENCES users(id),
    partner_id UUID NOT NULL REFERENCES partners(id),
    rating_score SMALLINT NOT NULL CHECK (rating_score BETWEEN 1 AND 5),
    comment TEXT,
    aspect_tags JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
`;
