/**
 * Refine Homes - 8 to 12 Week MVP Phased Implementation Roadmap
 */

export interface SprintDeliverable {
  title: string;
  category: 'Backend' | 'Customer App' | 'Partner App' | 'Admin & Ops' | 'Infra & QA';
  status: 'Completed' | 'In Progress' | 'Upcoming';
  description: string;
}

export interface RoadmapSprint {
  sprintNumber: number;
  weeks: string;
  theme: string;
  objective: string;
  deliverables: SprintDeliverable[];
  kpiMilestone: string;
}

export interface RiskItem {
  id: string;
  risk: string;
  severity: 'High' | 'Medium' | 'Low';
  probability: 'High' | 'Medium' | 'Low';
  mitigation: string;
}

export const MVP_ROADMAP_SPRINTS: RoadmapSprint[] = [
  {
    sprintNumber: 1,
    weeks: 'Weeks 1 - 2',
    theme: 'Core Engine, Schemas & Spatial Dispatch',
    objective: 'Establish clean architecture foundation, PostgreSQL + PostGIS schemas, Redis geohash indexing, and API gateway routing.',
    kpiMilestone: 'Dispatch radar benchmark: <250ms proximity query across 10,000 simulated partner pins.',
    deliverables: [
      {
        title: 'PostgreSQL & PostGIS Database Provisioning',
        category: 'Backend',
        status: 'Completed',
        description: 'Provision relational schemas for Users, Partners, Services, Bookings, Milestones, and Wallets with strict foreign key constraints.',
      },
      {
        title: 'Redis Geohash & Spatial Cluster Setup',
        category: 'Infra & QA',
        status: 'Completed',
        description: 'Implement Redis GEO commands (`GEOADD`, `GEORADIUSBYMEMBER`) with H3 resolution 8 for sub-second partner searches.',
      },
      {
        title: 'Authentication & OTP Microservice',
        category: 'Backend',
        status: 'Completed',
        description: 'Exotel/Twilio SMS integration for phone verification with rate limiting and secure JWT refresh rotation.',
      },
      {
        title: 'Design System & Mobile Skeleton',
        category: 'Customer App',
        status: 'Completed',
        description: 'Setup Flutter project architecture (BLoC/Riverpod pattern), design tokens, and theme configuration.',
      },
    ],
  },
  {
    sprintNumber: 2,
    weeks: 'Weeks 3 - 4',
    theme: 'Partner Onboarding & KYC Verification Pipeline',
    objective: 'Deliver the professional partner app with automated KYC verification, digital wallet ledger, and background check workflow.',
    kpiMilestone: 'KYC approval turnaround time reduced to <4 hours with automated OCR and manual Ops verification queue.',
    deliverables: [
      {
        title: 'Partner Flutter App Shell & Registration Flow',
        category: 'Partner App',
        status: 'Completed',
        description: 'Phone OTP signup, category specialization selection, and personal profile onboarding screens.',
      },
      {
        title: 'Aadhaar & Trade Certification KYC Pipeline',
        category: 'Partner App',
        status: 'Completed',
        description: 'Camera capture with AWS S3 pre-signed upload, automated document OCR extraction, and background verification trigger.',
      },
      {
        title: 'Admin KYC Review & Geofence Manager',
        category: 'Admin & Ops',
        status: 'Completed',
        description: 'React/Next.js ops dashboard view for reviewing submitted documents, marking verified, and configuring city polygons.',
      },
      {
        title: 'Partner Bank Account & IMPS Integration',
        category: 'Backend',
        status: 'Completed',
        description: 'Penny-drop bank account verification and Razorpay Fund Account creation for instant payouts.',
      },
    ],
  },
  {
    sprintNumber: 3,
    weeks: 'Weeks 5 - 6',
    theme: 'Customer App & Multi-Vertical Booking Workflows',
    objective: 'Implement all 4 service verticals in the Customer App: Painting inspection, Quick tasks hourly/fixed, Deep cleaning flat package, and Appliance repair.',
    kpiMilestone: '100% test coverage on multi-vertical dynamic form schemas and pricing matrices.',
    deliverables: [
      {
        title: 'Customer App Homepage & Dynamic Category Grid',
        category: 'Customer App',
        status: 'Completed',
        description: 'Service discovery grid with rich banners, search, and vertical-specific intake forms.',
      },
      {
        title: 'Instant Booking Engine (Plumbing & Cleaning)',
        category: 'Backend',
        status: 'Completed',
        description: '30-second cascading partner dispatch radar with Redis distributed locks preventing duplicate assignments.',
      },
      {
        title: 'Painting Site Visit & Measurement Flow',
        category: 'Customer App',
        status: 'Completed',
        description: 'Schedule expert site visit for wall inspection, laser measurement entry, and primer preference selection.',
      },
      {
        title: 'Appliance Repair Inspection + Spare Parts Model',
        category: 'Backend',
        status: 'Completed',
        description: '₹299 inspection visit fee booking with dynamic quotation amendment flow for newly identified spare parts.',
      },
    ],
  },
  {
    sprintNumber: 4,
    weeks: 'Weeks 7 - 8',
    theme: 'Digital Quotation, Escrow & Milestone Payments',
    objective: 'Build the partner measurement quotation generator and the 3-stage milestone escrow lock & release system with payment gateway.',
    kpiMilestone: 'Zero escrow reconciliation discrepancies during 1,000 synthetic multi-milestone booking runs.',
    deliverables: [
      {
        title: 'Partner Digital Quotation Generator (Painting)',
        category: 'Partner App',
        status: 'Completed',
        description: 'In-app room measurement calculator, paint brand tier selection (Asian Paints / Dulux), and instant estimate delivery to customer.',
      },
      {
        title: '3-Stage Milestone Escrow Engine',
        category: 'Backend',
        status: 'Completed',
        description: 'Automated 40% (Material) -> 40% (Prep/1st Coat) -> 20% (Final Signoff) escrow lock and partial unlock triggers.',
      },
      {
        title: 'Razorpay / Stripe Split Payments Integration',
        category: 'Backend',
        status: 'Completed',
        description: 'UPI, Cards, and Netbanking support with automated platform commission deduction (18%) and partner ledger credit.',
      },
      {
        title: 'Customer Quotation Review & Signature Signoff',
        category: 'Customer App',
        status: 'Completed',
        description: 'Interactive estimate review modal, digital signature acceptance, and initial milestone deposit checkout.',
      },
    ],
  },
  {
    sprintNumber: 5,
    weeks: 'Weeks 9 - 10',
    theme: 'Live Tracking, Number Masking & Real-Time Ops',
    objective: 'Implement live partner GPS tracking, Twilio masked telephony proxy, and the Ops dispatch command center.',
    kpiMilestone: 'Partner arrival ETA accuracy within +/- 3 minutes; zero leakage of personal phone numbers.',
    deliverables: [
      {
        title: 'WebSocket Live Location Tracking & Polyline Interpolation',
        category: 'Customer App',
        status: 'In Progress',
        description: 'Smooth map marker animation during partner transit using Socket.io and Google Maps Directions API.',
      },
      {
        title: 'Twilio / Exotel Virtual Call Masking Bridge',
        category: 'Backend',
        status: 'In Progress',
        description: 'Dynamic voice relay proxy ensuring customers and partners communicate without exposing real numbers.',
      },
      {
        title: 'Admin Surge Pricing & Demand Heatmap',
        category: 'Admin & Ops',
        status: 'In Progress',
        description: 'Live interactive map showing partner density, pending unassigned bookings, and real-time surge multiplier overrides.',
      },
      {
        title: 'Dispute Handling & Milestone Hold Mechanism',
        category: 'Admin & Ops',
        status: 'In Progress',
        description: 'Customer dissatisfaction escalation ticket flow with manual escrow freeze and mediator arbitration tools.',
      },
    ],
  },
  {
    sprintNumber: 6,
    weeks: 'Weeks 11 - 12',
    theme: 'End-to-End Hardening, Pilot Launch & Closed Beta',
    objective: 'Execute end-to-end chaos testing, load testing at 500 concurrent bookings, partner dry-run training, and launch pilot in 3 high-density pincodes.',
    kpiMilestone: '95%+ completed booking rate in pilot zone with average customer CSAT rating >= 4.7/5.0.',
    deliverables: [
      {
        title: 'Load Testing & Redis Lock Concurrency Audit',
        category: 'Infra & QA',
        status: 'Upcoming',
        description: 'Simulate flash booking spikes with k6/Locust to verify zero double-booking races under 2,000 req/sec.',
      },
      {
        title: 'Partner Onboarding Bootcamps & Kits Distribution',
        category: 'Partner App',
        status: 'Upcoming',
        description: 'Equip first cohort of 150 verified painters, plumbers, and technicians with branded uniforms and ID badges.',
      },
      {
        title: 'App Store & Google Play Store Submission',
        category: 'Customer App',
        status: 'Upcoming',
        description: 'Production signing, App Store Review guidelines compliance, and Google Play staging rollout.',
      },
      {
        title: 'Closed Beta Pilot Launch (Bengaluru East / Mumbai Bandra-Andheri)',
        category: 'Admin & Ops',
        status: 'Upcoming',
        description: 'Go-live in 3 selected pincodes with targeted local acquisition and 24/7 Ops War Room monitoring.',
      },
    ],
  },
];

export const MVP_RISK_REGISTER: RiskItem[] = [
  {
    id: 'R1',
    risk: 'Partner No-Show or Late Arrival on Instant Bookings',
    severity: 'High',
    probability: 'Medium',
    mitigation: 'Strict 30s acceptance timer, automated SLA penalty for tardiness, and instant 1-click auto-reassignment to next nearest partner within 500m.',
  },
  {
    id: 'R2',
    risk: 'Painting Quotation Scope Creep & Customer Dispute',
    severity: 'High',
    probability: 'High',
    mitigation: 'Standardized digital laser measurement sheet with timestamped wall photos before work starts; 3-stage milestone escrow locks money upfront so neither party is vulnerable.',
  },
  {
    id: 'R3',
    risk: 'Off-Platform Disintermediation (Cash Deals)',
    severity: 'Medium',
    probability: 'High',
    mitigation: 'Number masking via Twilio proxy, 30-day service warranty guarantee backed by Refine Homes only for in-app bookings, and partner repeat-booking bonus incentives.',
  },
  {
    id: 'R4',
    risk: 'Partner Double-Booking Race Condition under High Concurrency',
    severity: 'High',
    probability: 'Medium',
    mitigation: 'Distributed Redis lock (`Redlock`) with 35-second TTL tied to booking dispatch cycle, ensuring only one partner can claim a job.',
  },
  {
    id: 'R5',
    risk: 'Appliance Spare Part Price Inflation by Technicians',
    severity: 'Medium',
    probability: 'Medium',
    mitigation: 'Centralized admin spare parts catalog with pre-approved OEM pricing ranges; technician must take photo of old replaced part and OEM invoice.',
  },
];
