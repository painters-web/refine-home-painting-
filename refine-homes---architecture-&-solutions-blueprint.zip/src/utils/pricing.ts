/**
 * Refine Homes - Pure Pricing Engine & Milestone Escrow Math
 * Multi-vertical pricing calculators and financial distribution rules.
 */

export interface PaintingInput {
  carpetAreaSqFt: number;
  paintTier: 'economy' | 'premium' | 'luxury';
  includeCeiling: boolean;
  waterproofingSqFt?: number;
  primerCoats: number;
}

export interface PaintingEstimate {
  carpetAreaSqFt: number;
  effectiveWallSqFt: number;
  paintTierRatePerSqFt: number;
  basePaintCost: number;
  ceilingCost: number;
  waterproofingCost: number;
  primerCost: number;
  laborCost: number;
  subtotal: number;
  gstAmount: number; // 18% GST
  totalEstimate: number;
  milestones: {
    stage1Material: { percent: number; amount: number; label: string };
    stage2BaseCoat: { percent: number; amount: number; label: string };
    stage3FinalSignoff: { percent: number; amount: number; label: string };
  };
}

export interface QuickTaskInput {
  serviceType: 'plumbing' | 'electrical' | 'carpentry';
  pricingMode: 'hourly' | 'fixed';
  fixedBaseRate?: number;
  durationHours?: number;
  surgeMultiplier?: number;
  emergencyVisit?: boolean;
}

export interface CleaningInput {
  homeType: '1bhk' | '2bhk' | '3bhk' | '4bhk_villa';
  packageType: 'classic' | 'deep_pro' | 'move_in_out';
  addons: Array<{ id: string; name: string; price: number }>;
  surgeMultiplier?: number;
}

export interface ApplianceRepairInput {
  inspectionFee: number; // e.g. 299
  spareParts: Array<{ partName: string; cost: number }>;
  laborComplexityFee: number;
}

export interface PlatformSplit {
  grossAmount: number;
  platformCommissionRate: number; // e.g. 0.18 (18%)
  platformCommissionAmount: number;
  gatewayFeeRate: number; // e.g. 0.02 (2%)
  gatewayFeeAmount: number;
  partnerNetPayout: number;
}

const TIER_RATES = {
  economy: 14, // ₹14/sqft wall
  premium: 24, // ₹24/sqft wall
  luxury: 38,  // ₹38/sqft wall
};

/**
 * Calculates detailed painting quotation and 3-stage escrow milestones
 */
export function calculatePaintingEstimate(input: PaintingInput): PaintingEstimate {
  const carpetArea = Math.max(100, input.carpetAreaSqFt);
  // Standard rule: Wall area is roughly 3.2x carpet area for 10ft ceilings
  const effectiveWallSqFt = Math.round(carpetArea * 3.2);
  const ratePerSqFt = TIER_RATES[input.paintTier] || TIER_RATES.premium;

  const basePaintCost = effectiveWallSqFt * ratePerSqFt;
  const ceilingCost = input.includeCeiling ? carpetArea * (ratePerSqFt * 0.7) : 0;
  const waterproofingCost = (input.waterproofingSqFt || 0) * 35; // ₹35/sqft waterproofing
  const primerCost = (input.primerCoats || 1) * (effectiveWallSqFt * 4.5);
  const laborCost = Math.round(effectiveWallSqFt * 6.5);

  const subtotal = Math.round(basePaintCost + ceilingCost + waterproofingCost + primerCost + laborCost);
  const gstAmount = Math.round(subtotal * 0.18);
  const totalEstimate = subtotal + gstAmount;

  // 3-Stage Escrow Split: 40% Procurement, 40% Primer & 1st Coat, 20% Final Signoff
  const stage1Amount = Math.round(totalEstimate * 0.4);
  const stage2Amount = Math.round(totalEstimate * 0.4);
  const stage3Amount = totalEstimate - (stage1Amount + stage2Amount); // Guarantee exact sum

  return {
    carpetAreaSqFt: carpetArea,
    effectiveWallSqFt,
    paintTierRatePerSqFt: ratePerSqFt,
    basePaintCost,
    ceilingCost: Math.round(ceilingCost),
    waterproofingCost,
    primerCost: Math.round(primerCost),
    laborCost,
    subtotal,
    gstAmount,
    totalEstimate,
    milestones: {
      stage1Material: {
        percent: 40,
        amount: stage1Amount,
        label: 'Stage 1: Masking & Material Delivery (40%)',
      },
      stage2BaseCoat: {
        percent: 40,
        amount: stage2Amount,
        label: 'Stage 2: Surface Putty, Primer & 1st Coat (40%)',
      },
      stage3FinalSignoff: {
        percent: 20,
        amount: stage3Amount,
        label: 'Stage 3: 2nd Coat, Touch-up & Final QA Sign-off (20%)',
      },
    },
  };
}

/**
 * Calculates Quick Tasks (Plumbing/Electrical/Carpentry) pricing
 */
export function calculateQuickTaskPrice(input: QuickTaskInput): {
  baseAmount: number;
  surgeAmount: number;
  emergencyFee: number;
  gstAmount: number;
  totalAmount: number;
} {
  const surge = input.surgeMultiplier && input.surgeMultiplier >= 1 ? input.surgeMultiplier : 1.0;
  let baseAmount = 0;

  if (input.pricingMode === 'fixed') {
    baseAmount = input.fixedBaseRate || 399;
  } else {
    // Hourly: Base visiting fee covers first 60 mins (₹299), ₹199 each additional hour
    const hours = Math.max(1, Math.round(input.durationHours || 1));
    const firstHourRate = 299;
    const additionalHoursRate = 199;
    baseAmount = firstHourRate + (hours - 1) * additionalHoursRate;
  }

  const emergencyFee = input.emergencyVisit ? 150 : 0;
  const surgedBase = Math.round(baseAmount * surge);
  const surgeAmount = surgedBase - baseAmount;
  const subtotal = surgedBase + emergencyFee;
  const gstAmount = Math.round(subtotal * 0.18);
  const totalAmount = subtotal + gstAmount;

  return {
    baseAmount,
    surgeAmount,
    emergencyFee,
    gstAmount,
    totalAmount,
  };
}

/**
 * Calculates Deep Cleaning flat packages + addon services
 */
export function calculateCleaningPrice(input: CleaningInput): {
  basePackagePrice: number;
  addonsTotal: number;
  subtotal: number;
  surgeAmount: number;
  gstAmount: number;
  totalAmount: number;
} {
  const baseRates: Record<CleaningInput['homeType'], Record<CleaningInput['packageType'], number>> = {
    '1bhk': { classic: 1499, deep_pro: 2299, move_in_out: 2999 },
    '2bhk': { classic: 2199, deep_pro: 3299, move_in_out: 4299 },
    '3bhk': { classic: 2899, deep_pro: 4499, move_in_out: 5799 },
    '4bhk_villa': { classic: 3999, deep_pro: 6499, move_in_out: 8499 },
  };

  const basePackagePrice = baseRates[input.homeType]?.[input.packageType] || 2299;
  const addonsTotal = input.addons.reduce((sum, item) => sum + item.price, 0);
  const surge = input.surgeMultiplier && input.surgeMultiplier >= 1 ? input.surgeMultiplier : 1.0;

  const rawSubtotal = basePackagePrice + addonsTotal;
  const surgedSubtotal = Math.round(rawSubtotal * surge);
  const surgeAmount = surgedSubtotal - rawSubtotal;
  const gstAmount = Math.round(surgedSubtotal * 0.18);
  const totalAmount = surgedSubtotal + gstAmount;

  return {
    basePackagePrice,
    addonsTotal,
    subtotal: surgedSubtotal,
    surgeAmount,
    gstAmount,
    totalAmount,
  };
}

/**
 * Calculates Appliance Repair breakdown (Inspection fee + spare parts)
 */
export function calculateApplianceRepairPrice(input: ApplianceRepairInput): {
  inspectionFee: number;
  sparePartsTotal: number;
  laborComplexityFee: number;
  subtotal: number;
  gstAmount: number;
  totalAmount: number;
} {
  const partsSum = input.spareParts.reduce((acc, part) => acc + part.cost, 0);
  const subtotal = input.inspectionFee + partsSum + input.laborComplexityFee;
  const gstAmount = Math.round(subtotal * 0.18);
  const totalAmount = subtotal + gstAmount;

  return {
    inspectionFee: input.inspectionFee,
    sparePartsTotal: partsSum,
    laborComplexityFee: input.laborComplexityFee,
    subtotal,
    gstAmount,
    totalAmount,
  };
}

/**
 * Platform Take-rate & Partner Payout Escrow Split
 */
export function calculatePlatformSplit(grossAmount: number, commissionRate = 0.18): PlatformSplit {
  const platformCommissionAmount = Math.round(grossAmount * commissionRate);
  const gatewayFeeAmount = Math.round(grossAmount * 0.02); // 2% gateway processing
  const partnerNetPayout = grossAmount - platformCommissionAmount - gatewayFeeAmount;

  return {
    grossAmount,
    platformCommissionRate: commissionRate,
    platformCommissionAmount,
    gatewayFeeRate: 0.02,
    gatewayFeeAmount,
    partnerNetPayout,
  };
}
