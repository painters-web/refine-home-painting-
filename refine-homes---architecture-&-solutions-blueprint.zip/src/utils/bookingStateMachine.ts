/**
 * Refine Homes - Booking State Machine & Partner Matching Engine
 * Manages deterministic state transitions for Instant and Milestone lifecycles.
 */

export type InstantBookingState =
  | 'REQUESTED'
  | 'MATCHING_RADAR'
  | 'PARTNER_ASSIGNED'
  | 'EN_ROUTE'
  | 'ARRIVED'
  | 'WORK_STARTED'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'EXPIRED';

export type MilestoneBookingState =
  | 'LEAD_CREATED'
  | 'SITE_VISIT_SCHEDULED'
  | 'INSPECTION_COMPLETED'
  | 'ESTIMATE_PENDING_APPROVAL'
  | 'ESTIMATE_APPROVED'
  | 'STAGE1_MATERIAL_LOCKED'
  | 'STAGE1_VERIFIED'
  | 'STAGE2_SURFACE_IN_PROGRESS'
  | 'STAGE2_VERIFIED'
  | 'STAGE3_FINAL_QA'
  | 'JOB_COMPLETED_SETTLED'
  | 'DISPUTE_RAISED';

export interface PartnerCandidate {
  id: string;
  name: string;
  phone: string;
  category: string;
  rating: number;
  completedJobsCount: number;
  latitude: number;
  longitude: number;
  isKycVerified: boolean;
  isOnline: boolean;
  hasActiveJob: boolean;
}

/**
 * Validates permitted transitions for Instant Booking (Plumbing, Cleaning, Appliance)
 */
export function canTransitionInstantState(
  from: InstantBookingState,
  to: InstantBookingState
): boolean {
  const allowedTransitions: Record<InstantBookingState, InstantBookingState[]> = {
    REQUESTED: ['MATCHING_RADAR', 'CANCELLED'],
    MATCHING_RADAR: ['PARTNER_ASSIGNED', 'EXPIRED', 'CANCELLED'],
    PARTNER_ASSIGNED: ['EN_ROUTE', 'CANCELLED', 'MATCHING_RADAR'],
    EN_ROUTE: ['ARRIVED', 'CANCELLED'],
    ARRIVED: ['WORK_STARTED', 'CANCELLED'],
    WORK_STARTED: ['COMPLETED', 'CANCELLED'],
    COMPLETED: [],
    CANCELLED: [],
    EXPIRED: ['MATCHING_RADAR', 'CANCELLED'],
  };

  return allowedTransitions[from]?.includes(to) ?? false;
}

/**
 * Validates permitted transitions for Milestone Booking (Painting, Waterproofing)
 */
export function canTransitionMilestoneState(
  from: MilestoneBookingState,
  to: MilestoneBookingState
): boolean {
  const allowedTransitions: Record<MilestoneBookingState, MilestoneBookingState[]> = {
    LEAD_CREATED: ['SITE_VISIT_SCHEDULED', 'DISPUTE_RAISED'],
    SITE_VISIT_SCHEDULED: ['INSPECTION_COMPLETED', 'DISPUTE_RAISED'],
    INSPECTION_COMPLETED: ['ESTIMATE_PENDING_APPROVAL', 'DISPUTE_RAISED'],
    ESTIMATE_PENDING_APPROVAL: ['ESTIMATE_APPROVED', 'DISPUTE_RAISED'],
    ESTIMATE_APPROVED: ['STAGE1_MATERIAL_LOCKED', 'DISPUTE_RAISED'],
    STAGE1_MATERIAL_LOCKED: ['STAGE1_VERIFIED', 'DISPUTE_RAISED'],
    STAGE1_VERIFIED: ['STAGE2_SURFACE_IN_PROGRESS', 'DISPUTE_RAISED'],
    STAGE2_SURFACE_IN_PROGRESS: ['STAGE2_VERIFIED', 'DISPUTE_RAISED'],
    STAGE2_VERIFIED: ['STAGE3_FINAL_QA', 'DISPUTE_RAISED'],
    STAGE3_FINAL_QA: ['JOB_COMPLETED_SETTLED', 'DISPUTE_RAISED'],
    JOB_COMPLETED_SETTLED: [],
    DISPUTE_RAISED: ['ESTIMATE_PENDING_APPROVAL', 'STAGE2_SURFACE_IN_PROGRESS', 'JOB_COMPLETED_SETTLED'],
  };

  return allowedTransitions[from]?.includes(to) ?? false;
}

/**
 * Calculates Haversine distance in kilometers between two GPS coordinates
 */
export function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

/**
 * Filters and ranks eligible partners for dispatch based on proximity, KYC, and rating
 */
export function rankEligiblePartners(
  partners: PartnerCandidate[],
  customerLat: number,
  customerLon: number,
  requiredCategory: string,
  maxRadiusKm = 10
): Array<PartnerCandidate & { distanceKm: number; score: number }> {
  return partners
    .filter((partner) => {
      if (!partner.isKycVerified) return false;
      if (!partner.isOnline) return false;
      if (partner.hasActiveJob) return false;
      if (partner.category.toLowerCase() !== requiredCategory.toLowerCase()) return false;
      return true;
    })
    .map((partner) => {
      const distanceKm = calculateHaversineDistanceKm(
        customerLat,
        customerLon,
        partner.latitude,
        partner.longitude
      );
      // Scoring formula: High rating weights 40%, Low distance weights 60%
      // Distance penalty: (maxRadius - distance) / maxRadius
      const distanceScore = Math.max(0, (maxRadiusKm - distanceKm) / maxRadiusKm) * 60;
      const ratingScore = (partner.rating / 5) * 40;
      const score = Math.round((distanceScore + ratingScore) * 10) / 10;

      return {
        ...partner,
        distanceKm,
        score,
      };
    })
    .filter((p) => p.distanceKm <= maxRadiusKm)
    .sort((a, b) => b.score - a.score);
}
