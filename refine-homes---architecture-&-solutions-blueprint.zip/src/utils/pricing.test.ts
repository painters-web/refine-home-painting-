import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculatePaintingEstimate,
  calculateQuickTaskPrice,
  calculateCleaningPrice,
  calculateApplianceRepairPrice,
  calculatePlatformSplit,
} from './pricing.ts';

test('Painting estimate computes 3-stage milestone escrow summing to totalEstimate', () => {
  const estimate = calculatePaintingEstimate({
    carpetAreaSqFt: 1000,
    paintTier: 'premium',
    includeCeiling: true,
    primerCoats: 1,
    waterproofingSqFt: 200,
  });

  assert.ok(estimate.totalEstimate > 0);
  assert.equal(estimate.effectiveWallSqFt, 3200);
  assert.equal(estimate.paintTierRatePerSqFt, 24);

  // Validate milestones sum up to exact totalEstimate
  const sumMilestones =
    estimate.milestones.stage1Material.amount +
    estimate.milestones.stage2BaseCoat.amount +
    estimate.milestones.stage3FinalSignoff.amount;

  assert.equal(sumMilestones, estimate.totalEstimate);
  assert.equal(estimate.milestones.stage1Material.percent, 40);
  assert.equal(estimate.milestones.stage2BaseCoat.percent, 40);
  assert.equal(estimate.milestones.stage3FinalSignoff.percent, 20);
});

test('Quick task calculates hourly and surge pricing accurately', () => {
  const result = calculateQuickTaskPrice({
    serviceType: 'plumbing',
    pricingMode: 'hourly',
    durationHours: 3,
    surgeMultiplier: 1.2,
    emergencyVisit: true,
  });

  // Base: 299 + (2 * 199) = 697
  // Surge: round(697 * 1.2) = 836. Surge amount = 139. Emergency = 150.
  // Subtotal = 836 + 150 = 986. GST = round(986 * 0.18) = 177. Total = 1163.
  assert.equal(result.baseAmount, 697);
  assert.equal(result.emergencyFee, 150);
  assert.ok(result.totalAmount > result.baseAmount);
});

test('Deep cleaning adds package, addons and calculates GST', () => {
  const result = calculateCleaningPrice({
    homeType: '2bhk',
    packageType: 'deep_pro',
    addons: [
      { id: 'balcony', name: 'Balcony Wash', price: 499 },
      { id: 'sofa', name: 'Sofa Shampooing', price: 799 },
    ],
    surgeMultiplier: 1.0,
  });

  // Base = 3299 + 499 + 799 = 4597. GST (18%) = 827. Total = 5424.
  assert.equal(result.basePackagePrice, 3299);
  assert.equal(result.addonsTotal, 1298);
  assert.equal(result.subtotal, 4597);
  assert.equal(result.totalAmount, 4597 + Math.round(4597 * 0.18));
});

test('Appliance repair aggregates inspection fee, parts and labor', () => {
  const result = calculateApplianceRepairPrice({
    inspectionFee: 299,
    spareParts: [
      { partName: 'AC PCB Board', cost: 1450 },
      { partName: 'Capacitor', cost: 350 },
    ],
    laborComplexityFee: 400,
  });

  // Subtotal: 299 + 1800 + 400 = 2499. GST = round(2499 * 0.18) = 450. Total = 2949.
  assert.equal(result.inspectionFee, 299);
  assert.equal(result.sparePartsTotal, 1800);
  assert.equal(result.subtotal, 2499);
  assert.equal(result.totalAmount, 2949);
});

test('Platform split allocates commission, gateway fee and net partner payout', () => {
  const split = calculatePlatformSplit(10000, 0.18);
  assert.equal(split.grossAmount, 10000);
  assert.equal(split.platformCommissionAmount, 1800); // 18%
  assert.equal(split.gatewayFeeAmount, 200); // 2%
  assert.equal(split.partnerNetPayout, 8000); // 80%
  assert.equal(
    split.platformCommissionAmount + split.gatewayFeeAmount + split.partnerNetPayout,
    split.grossAmount
  );
});
