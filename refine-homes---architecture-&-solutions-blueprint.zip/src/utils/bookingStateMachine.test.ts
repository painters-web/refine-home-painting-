import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canTransitionInstantState,
  canTransitionMilestoneState,
  calculateHaversineDistanceKm,
  rankEligiblePartners,
  PartnerCandidate,
} from './bookingStateMachine.ts';

test('Instant booking transitions enforce correct lifecycle stages', () => {
  assert.equal(canTransitionInstantState('REQUESTED', 'MATCHING_RADAR'), true);
  assert.equal(canTransitionInstantState('MATCHING_RADAR', 'PARTNER_ASSIGNED'), true);
  assert.equal(canTransitionInstantState('PARTNER_ASSIGNED', 'ARRIVED'), false); // Cannot skip EN_ROUTE
  assert.equal(canTransitionInstantState('PARTNER_ASSIGNED', 'EN_ROUTE'), true);
  assert.equal(canTransitionInstantState('EN_ROUTE', 'ARRIVED'), true);
  assert.equal(canTransitionInstantState('COMPLETED', 'REQUESTED'), false);
});

test('Milestone booking transitions follow inspection to escrow completion', () => {
  assert.equal(canTransitionMilestoneState('LEAD_CREATED', 'SITE_VISIT_SCHEDULED'), true);
  assert.equal(canTransitionMilestoneState('SITE_VISIT_SCHEDULED', 'INSPECTION_COMPLETED'), true);
  assert.equal(canTransitionMilestoneState('INSPECTION_COMPLETED', 'ESTIMATE_PENDING_APPROVAL'), true);
  assert.equal(canTransitionMilestoneState('ESTIMATE_PENDING_APPROVAL', 'ESTIMATE_APPROVED'), true);
  assert.equal(canTransitionMilestoneState('ESTIMATE_APPROVED', 'STAGE1_MATERIAL_LOCKED'), true);
  assert.equal(canTransitionMilestoneState('STAGE1_MATERIAL_LOCKED', 'STAGE1_VERIFIED'), true);
  assert.equal(canTransitionMilestoneState('STAGE1_VERIFIED', 'STAGE2_SURFACE_IN_PROGRESS'), true);
  assert.equal(canTransitionMilestoneState('STAGE2_VERIFIED', 'STAGE3_FINAL_QA'), true);
  assert.equal(canTransitionMilestoneState('STAGE3_FINAL_QA', 'JOB_COMPLETED_SETTLED'), true);
  // Disallowed backwards skip
  assert.equal(canTransitionMilestoneState('LEAD_CREATED', 'JOB_COMPLETED_SETTLED'), false);
});

test('Haversine distance calculation is accurate', () => {
  // Distance between Mumbai Bandra (19.0596, 72.8295) and Andheri (19.1136, 72.8697) ~ 7.3 km
  const distance = calculateHaversineDistanceKm(19.0596, 72.8295, 19.1136, 72.8697);
  assert.ok(distance >= 6.5 && distance <= 8.5);
});

test('rankEligiblePartners filters unverified or busy partners and ranks by score', () => {
  const partners: PartnerCandidate[] = [
    {
      id: 'p1',
      name: 'Ramesh Plumber',
      phone: '+919876543210',
      category: 'plumbing',
      rating: 4.8,
      completedJobsCount: 154,
      latitude: 19.062,
      longitude: 72.831, // ~0.3 km away
      isKycVerified: true,
      isOnline: true,
      hasActiveJob: false,
    },
    {
      id: 'p2',
      name: 'Suresh Unverified',
      phone: '+919876543211',
      category: 'plumbing',
      rating: 4.9,
      completedJobsCount: 200,
      latitude: 19.060,
      longitude: 72.830,
      isKycVerified: false, // Unverified - should be excluded
      isOnline: true,
      hasActiveJob: false,
    },
    {
      id: 'p3',
      name: 'Dinesh Busy',
      phone: '+919876543212',
      category: 'plumbing',
      rating: 4.7,
      completedJobsCount: 89,
      latitude: 19.060,
      longitude: 72.830,
      isKycVerified: true,
      isOnline: true,
      hasActiveJob: true, // Busy - should be excluded
    },
    {
      id: 'p4',
      name: 'Vikram Far Away',
      phone: '+919876543213',
      category: 'plumbing',
      rating: 4.5,
      completedJobsCount: 42,
      latitude: 19.300,
      longitude: 73.000, // ~30 km away - should be excluded by 10km radius
      isKycVerified: true,
      isOnline: true,
      hasActiveJob: false,
    },
  ];

  const ranked = rankEligiblePartners(partners, 19.0596, 72.8295, 'plumbing', 10);
  assert.equal(ranked.length, 1);
  assert.equal(ranked[0].id, 'p1');
  assert.ok(ranked[0].distanceKm < 1.0);
  assert.ok(ranked[0].score > 80);
});
