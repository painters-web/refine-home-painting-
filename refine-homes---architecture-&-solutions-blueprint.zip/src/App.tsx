import React, { useState, useEffect } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { ArchitectureView } from './components/ArchitectureView';
import { SimulatorView } from './components/SimulatorView';
import { BookingFlowView } from './components/BookingFlowView';
import { DatabaseSchemaView } from './components/DatabaseSchemaView';
import { RoadmapView } from './components/RoadmapView';
import { DocumentationView } from './components/DocumentationView';
import {
  Layers,
  Smartphone,
  GitBranch,
  Database,
  Calendar,
  FileText,
  ShieldCheck,
  Zap,
  ExternalLink,
  Github,
  Heart,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('architecture');

  // Handle URL hash or autostart query parameter if present
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get('tab') as TabType;
    if (tabParam && ['architecture', 'simulator', 'booking-flow', 'database', 'roadmap', 'specification'].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportDoc={() => setActiveTab('specification')}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'architecture' && <ArchitectureView />}
        {activeTab === 'simulator' && <SimulatorView />}
        {activeTab === 'booking-flow' && <BookingFlowView />}
        {activeTab === 'database' && <DatabaseSchemaView />}
        {activeTab === 'roadmap' && <RoadmapView />}
        {activeTab === 'specification' && <DocumentationView />}
      </main>

      {/* Global Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 py-6 text-xs text-slate-400 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-200">Refine Homes</span>
            <span>&bull; Principal Solutions Architect & Product Manager Blueprint</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setActiveTab('architecture')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              C4 Architecture
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setActiveTab('simulator')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Live Simulator
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setActiveTab('database')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              PostgreSQL DDL
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setActiveTab('roadmap')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              12-Wk Roadmap
            </button>
          </div>

          <div className="text-slate-500 text-[11px]">
            Designed for Urban Company-Scale Multi-Vertical Operations
          </div>
        </div>
      </footer>
    </div>
  );
}
